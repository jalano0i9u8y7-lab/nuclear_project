/**
 * 📈 P3: 技術分析 - 快照管理模組
 * 
 * 負責快照的讀取、保存、比對、自動觸發檢查
 * 
 * @version SSOT V7.1
 * @date 2025-01-11
 */

// ==========================================
// 快照讀取
// ==========================================

/**
 * 獲取最新的 P3 快照
 * 
 * @returns {Object|null} snapshot - 快照數據或 null
 */
function getLatestP3Snapshot() {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName("P3__SNAPSHOT");
    
    if (!sheet || sheet.getLastRow() <= 1) {
      return null;
    }
    
    const lastRow = sheet.getLastRow();
    const row = sheet.getRange(lastRow, 1, 1, 9).getValues()[0];
    
    return {
      snapshot_id: row[0],
      created_at: row[1],
      trigger: row[2],
      prevent_recursive: row[3] || false,
      technical_results_json: row[4] ? JSON.parse(row[4]) : {},
      changes_json: row[5] ? JSON.parse(row[5]) : null,
      auto_trigger_json: row[6] ? JSON.parse(row[6]) : null,
      data_freshness_json: row[7] ? JSON.parse(row[7]) : null,
      version: row[8] || "V7.1"
    };
  } catch (error) {
    Logger.log(`讀取 P3 最新快照失敗：${error.message}`);
    return null;
  }
}

// ==========================================
// 快照保存
// ==========================================

/**
 * 保存 P3 快照
 * 
 * @param {Object} snapshotData - 快照數據
 * @returns {Object} snapshot - 保存後的快照信息
 */
function saveP3Snapshot(snapshotData) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName("P3__SNAPSHOT");
  
  if (!sheet) {
    sheet = ss.insertSheet("P3__SNAPSHOT");
    sheet.appendRow(P3_SNAPSHOT_SCHEMA.headers);
    sheet.setFrozenRows(1);
  }
  
  const snapshotId = generateP3SnapshotId(snapshotData.frequency);
  
  sheet.appendRow([
    snapshotId,
    new Date(),
    snapshotData.trigger,
    snapshotData.prevent_recursive || false,
    JSON.stringify(snapshotData.technical_results),
    JSON.stringify(snapshotData.changes),
    JSON.stringify(snapshotData.auto_trigger),
    JSON.stringify(snapshotData.data_freshness),
    "V7.1"
  ]);
  
  Logger.log(`P3 快照已保存：snapshot_id=${snapshotId}`);
  
  return {
    snapshot_id: snapshotId,
    changes: snapshotData.changes
  };
}

/**
 * 生成 P3 快照 ID
 * 
 * @param {string} frequency - 執行頻率（WEEKLY/MONTHLY）
 * @returns {string} snapshotId - 快照 ID
 */
function generateP3SnapshotId(frequency) {
  const date = new Date();
  const year = date.getFullYear();
  const week = getWeekNumber(date);
  const month = date.getMonth() + 1;
  
  if (frequency === "WEEKLY") {
    return `P3_W${year}W${week}_${Date.now()}`;
  } else {
    return `P3_M${year}M${month}_${Date.now()}`;
  }
}

/**
 * 計算週數
 * 
 * @param {Date} date - 日期
 * @returns {number} week - 週數
 */
function getWeekNumber(date) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
}

// ==========================================
// 快照比對
// ==========================================

/**
 * 比對當前輸出與上一版快照
 * 
 * @param {Object} currentOutput - 當前輸出
 * @returns {Object} changes - 變動信息
 */
function compareWithPreviousSnapshotP3(currentOutput) {
  const previousSnapshot = getLatestP3Snapshot();
  
  if (!previousSnapshot) {
    return {
      has_changes: true,
      is_first_run: true,
      changes: []
    };
  }
  
  const previousResults = previousSnapshot.technical_results_json || {};
  const currentResults = currentOutput.technical_results || {};
  const changes = [];
  
  // 比對 Cat 變動
  const catChanges = [];
  for (const [ticker, currentResult] of Object.entries(currentResults)) {
    const previousResult = previousResults[ticker];
    
    if (!previousResult || previousResult.cat !== currentResult.cat) {
      catChanges.push({
        ticker: ticker,
        from: previousResult ? previousResult.cat : "NEW",
        to: currentResult.cat
      });
    }
  }
  
  if (catChanges.length > 0) {
    changes.push({
      type: "CAT_CHANGES",
      changes: catChanges
    });
  }
  
  return {
    has_changes: changes.length > 0 || catChanges.length > 0,
    is_first_run: false,
    changes: changes
  };
}

// ==========================================
// 自動觸發檢查
// ==========================================

/**
 * 檢查自動觸發條件
 * 
 * @param {Object} p3Output - P3 輸出
 * @returns {Object} autoTrigger - 自動觸發信息
 */
function checkAutoTriggerConditionsP3(p3Output) {
  const autoTriggers = [];
  const catChanges = p3Output.changes?.find(c => c.type === "CAT_CHANGES");
  
  if (catChanges && catChanges.changes.length > 0) {
    // Cat 變動 → 自動觸發 P4
    autoTriggers.push({
      type: "CAT_CHANGE",
      trigger_phase: "P4",
      changed_stocks: catChanges.changes.map(c => c.ticker)
    });
  }
  
  return {
    triggers: autoTriggers,
    should_trigger_p4: autoTriggers.length > 0
  };
}

// ==========================================
// 數據新鮮度檢查
// ==========================================

/**
 * 檢查技術數據新鮮度
 * 
 * @param {Object} technicalData - 技術指標數據
 * @returns {Object} freshness - 新鮮度信息
 */
function checkDataFreshness(technicalData) {
  const freshness = {};
  
  for (const [ticker, data] of Object.entries(technicalData)) {
    if (data.last_updated) {
      const daysSinceUpdate = (new Date() - new Date(data.last_updated)) / (1000 * 60 * 60 * 24);
      freshness[ticker] = {
        last_updated: data.last_updated,
        days_since_update: daysSinceUpdate,
        is_fresh: daysSinceUpdate <= 1  // 1 天內為新鮮
      };
    }
  }
  
  return freshness;
}
