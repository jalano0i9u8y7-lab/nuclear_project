/**
 * ⭐ V8.14 新增：P1 兩階段執行模組
 * 
 * 實作 P1 兩階段執行：
 * - Step 1：股票池生成（Gemini Flash 3.0）
 * - Step 2：結構分級（Gemini Pro 3.0）
 * 
 * @version V8.14
 * @date 2026-01-19
 */

// ==========================================
// P1 Step 1：股票池生成（Gemini Flash 3.0）
// ==========================================

/**
 * 構建 P1 Step 1 Prompt（股票池生成）
 * @param {Object} userInput - 用戶輸入
 * @param {Object} p0Output - P0 輸出
 * @param {Object} p0_5Output - P0.5 輸出（產業鏈地圖）
 * @param {Object} p0_7Output - P0.7 輸出
 * @return {string} Prompt 內容
 */
function buildP1Step1Prompt(userInput, p0Output, p0_5Output, p0_7Output) {
  const isTestMode = (userInput && userInput.test_mode === true) || 
                     (userInput && userInput.context && userInput.context.test_mode === true);
  
  return `
## 🏢 P1 Step 1：股票池生成（Universe Expansion）

**你的角色**：資料蒐集員（使用 Gemini Flash 3.0）

**你的任務**：根據 P0/P0.5/P0.7 的結論，找出所有相關公司，**僅做資料蒐集，不做任何分析**。

---

## ⚠️ 重要：職權邊界（嚴格限制）

**✅ 你可以做**：
- 根據 P0/P0.5/P0.7 找出所有相關公司（上游/中游/下游/互補性產業/受害性產業）
- 產出 15-30 檔公司清單（美:台:日 = 5:3:2，建議比例，無法達成沒關係）
- 提供公司基本資訊（ticker, company_name, market）

**❌ 絕對禁止**：
- ❌ **進行任何分析**（財務分析、估值分析、技術分析）
- ❌ **判斷產業鏈位置**（這是 Step 2 的職責）
- ❌ **獵殺舊技術龍頭**（這是 Step 2 的職責）
- ❌ **讀取財報**（財報將由系統自動下載後統一處理）
- ❌ **改寫 P0 主敘事或加入新宏觀論述**

**P1 Step 1 僅做資料蒐集，不做任何分析或判斷**

---

## 📥 輸入：P0/P0.5/P0.7 的分析結果

### P0 輸出（必然位置表）
${JSON.stringify(p0Output, null, 2)}

### P0.5 輸出（產業鏈地圖）
${JSON.stringify(p0_5Output, null, 2)}

### P0.7 輸出（系統動力學分析）
${JSON.stringify(p0_7Output, null, 2)}

---

## 🎯 你的分析任務

### **任務 1：股票池生成（Universe Expansion）**

針對 P0 選出的每個 Theme/Subtheme，找出所有相關公司：

1. **上游（Upstream）**：
   - 原材料供應商
   - 關鍵設備供應商
   - 基礎技術提供者
   - 識別每個上游節點的關鍵公司（美股/台股/日股）

2. **中游（Midstream）**：
   - 關鍵製程（Critical Processes）
   - 關鍵模組（Critical Modules）
   - 組裝/整合環節
   - 識別每個中游節點的關鍵公司（美股/台股/日股）

3. **下游（Downstream）**：
   - 終端應用場景
   - 終端客戶/市場
   - 分銷渠道
   - 識別每個下游節點的關鍵公司（美股/台股/日股）

4. **互補性產業（Complementary）**：
   - 與該產業互補的產業/公司
   - 識別互補性產業的關鍵公司（美股/台股/日股）

5. **受害性產業（Victim/Squeezed）** ⭐ **必須主動獵殺**：
   - 根據 P0 的技術替代路徑（例如光取代銅），**主動搜尋「目前提供舊技術的主流公司」**
   - 將其列入清單並標記為 Tier X 候選
   - 識別受害性產業的關鍵公司（美股/台股/日股）

**數量要求**：
- 每個產業建議 15-30 檔公司
- 市場比例建議：美:台:日 = 5:3:2（無法達成沒關係）

**注意**：
- 你只需要提供公司清單，不需要讀取財報
- 財報將由系統自動下載後統一處理
- 你不需要判斷公司在產業鏈的位置（這是 Step 2 的職責）

---

## 📤 輸出格式

請按照以下 JSON 格式輸出：

{
  "company_pool": [
    {
      "ticker": "AAPL",
      "company_name": "Apple Inc.",
      "market": "US",
      "theme_id": "THEME_001",
      "subtheme_id": "SUBTHEME_001",
      "potential_categories": ["Upstream", "Midstream", "Downstream", "Complementary", "Victim"],
      "notes": "初步判斷可能屬於的類別（僅供參考，最終由 Step 2 判斷）"
    }
  ],
  "summary": {
    "total_companies": 25,
    "us_companies": 12,
    "tw_companies": 8,
    "jp_companies": 5
  }
}

---

## ⚠️ 輸出要求

1. **必須完全來自系統內已完成的 P0/P0.5/P0.7**：
   - 不可以重作新產業分析
   - 不可以網路搜尋「非官方」資料
   - 只可以根據 P0/P0.5/P0.7 的結論找出相關公司

2. **僅做資料蒐集，不做分析**：
   - 不需要判斷公司在產業鏈的位置（這是 Step 2 的職責）
   - 不需要獵殺舊技術龍頭（這是 Step 2 的職責）
   - 不需要讀取財報（財報將由系統自動下載後統一處理）

3. **保持客觀描述**：
   - 使用事實性描述，避免主觀判斷
   - 只提供公司基本資訊（ticker, company_name, market）
`;
}

/**
 * 處理 P1 Step 1 結果
 * @param {string} jobId - Job ID
 * @param {Object} m0Result - M0 執行結果
 * @return {Object} Step 1 處理結果
 */
function P1_ProcessStep1Result(jobId, m0Result) {
  try {
    Logger.log(`P1 V8.14：處理 Step 1 結果，jobId=${jobId}`);
    
    const executorOutput = m0Result.executor_output || m0Result.output || {};
    
    // 解析輸出
    let step1Output = {};
    if (typeof executorOutput === 'string') {
      try {
        let jsonString = executorOutput.trim();
        if (jsonString.startsWith('```json')) {
          jsonString = jsonString.replace(/^```json\s*/, '').replace(/\s*```$/, '');
        } else if (jsonString.startsWith('```')) {
          jsonString = jsonString.replace(/^```\s*/, '').replace(/\s*```$/, '');
        }
        step1Output = JSON.parse(jsonString);
      } catch (e) {
        Logger.log(`P1 V8.14：無法解析 Step 1 executorOutput：${e.message}`);
        step1Output = executorOutput;
      }
    } else {
      step1Output = executorOutput;
    }
    
    // 驗證公司池結構
    if (!step1Output.company_pool || !Array.isArray(step1Output.company_pool)) {
      throw new Error("Step 1 輸出缺少 company_pool 欄位或格式不正確");
    }
    
    Logger.log(`P1 V8.14：Step 1 生成 ${step1Output.company_pool.length} 檔公司`);
    
    // ⭐ 新增：財報下載階段
    Logger.log(`P1 V8.14：開始財報下載階段`);
    const financialReportStatus = P1_FetchFinancialReports(step1Output.company_pool, jobId);
    
    return {
      status: "COMPLETED",
      job_id: jobId,
      company_pool: step1Output.company_pool,
      summary: step1Output.summary || {},
      financial_report_status: financialReportStatus
    };
    
  } catch (error) {
    Logger.log(`P1 V8.14：處理 Step 1 結果失敗：${error.message}`);
    throw error;
  }
}

// ==========================================
// P1 Step 2：結構分級（Gemini Pro 3.0）
// ==========================================

/**
 * 執行 P1 Step 2（結構分級）
 * @param {Object} step1Result - Step 1 處理結果
 * @param {Object} params - 原始執行參數
 * @return {Object} Step 2 執行結果
 */
function P1_ExecuteStep2(step1Result, params) {
  try {
    Logger.log(`P1 V8.14：開始執行 Step 2（結構分級）`);
    
    // 1. 讀取 P0/P0.5/P0.7 輸出（從 params 獲取，如果沒有則從快照讀取）
    let p0Output, p0_5Output, p0_7Output;
    let p0Snapshot, p0_5Snapshot, p0_7Snapshot;
    
    if (params.p0_output && params.p0_5_output && params.p0_7_output) {
      // 直接使用 params 中的輸出（避免重複讀取）
      p0Output = params.p0_output;
      p0_5Output = params.p0_5_output;
      p0_7Output = params.p0_7_output;
      
      // 如果 params 中有 snapshot_id，也保存起來
      if (params.p0_snapshot_id) {
        p0Snapshot = { snapshot_id: params.p0_snapshot_id };
      }
      if (params.p0_5_snapshot_id) {
        p0_5Snapshot = { snapshot_id: params.p0_5_snapshot_id };
      }
      if (params.p0_7_snapshot_id) {
        p0_7Snapshot = { snapshot_id: params.p0_7_snapshot_id };
      }
    } else {
      // 從快照讀取
      p0Snapshot = getP0SnapshotById(params.p0_snapshot_id);
      p0_5Snapshot = getP0_5SnapshotById(params.p0_5_snapshot_id);
      p0_7Snapshot = getP0_7SnapshotById(params.p0_7_snapshot_id);
      
      if (!p0Snapshot || !p0Snapshot.p0_output_json) {
        throw new Error("P0 快照不存在或缺少數據");
      }
      if (!p0_5Snapshot || !p0_5Snapshot.p0_5_output_json) {
        throw new Error("P0.5 快照不存在或缺少數據");
      }
      if (!p0_7Snapshot || !p0_7Snapshot.p0_7_output_json) {
        throw new Error("P0.7 快照不存在或缺少數據");
      }
      
      p0Output = typeof p0Snapshot.p0_output_json === 'string' ?
        JSON.parse(p0Snapshot.p0_output_json) : p0Snapshot.p0_output_json;
      p0_5Output = typeof p0_5Snapshot.p0_5_output_json === 'string' ?
        JSON.parse(p0_5Snapshot.p0_5_output_json) : p0_5Snapshot.p0_5_output_json;
      p0_7Output = typeof p0_7Snapshot.p0_7_output_json === 'string' ?
        JSON.parse(p0_7Snapshot.p0_7_output_json) : p0_7Snapshot.p0_7_output_json;
    }
    
    // 2. 讀取 Flash 提取的財報資料（從表格中讀取）
    const financialReportData = loadFinancialReportExtractions(step1Result.company_pool);
    
    // 3. 構建 Step 2 Prompt（包含 Flash 提取的資料）
    const step2Prompt = buildP1Step2Prompt(step1Result.company_pool, financialReportData, p0Output, p0_5Output, p0_7Output);
    
    // 3. 準備 M0 Job 輸入
    const m0InputPayload_Step2 = {
      phase: "P1_STEP2",
      trigger: params.trigger || "QUARTERLY",
      step1_result: step1Result,
      company_pool: step1Result.company_pool,
      financial_report_data: financialReportData,  // ⭐ V8.14 新增：傳遞 Flash 提取的財報資料給審查者
      p0_output: p0Output,
      p0_5_output: p0_5Output,
      p0_7_output: p0_7Output,
      p0_snapshot_id: p0Snapshot ? p0Snapshot.snapshot_id : params.p0_snapshot_id || null,
      p0_5_snapshot_id: p0_5Snapshot ? p0_5Snapshot.snapshot_id : params.p0_5_snapshot_id || null,
      p0_7_snapshot_id: p0_7Snapshot ? p0_7Snapshot.snapshot_id : params.p0_7_snapshot_id || null,
      p1_step2_prompt: step2Prompt,
      context: params.context || {}
    };
    
    // 4. 提交到 M0 Job Queue
    const requestedFlow_Step2 = [
      "EXECUTOR",  // Gemini Pro 3.0（結構分級）
      "AUDITOR"    // GPT-5.2（審查）
    ];
    
    const jobId_Step2 = submitToM0JobQueue("P1_STEP2", requestedFlow_Step2, m0InputPayload_Step2);
    Logger.log(`P1 V8.14：已提交 Step 2（結構分級）到 M0 Job Queue，jobId=${jobId_Step2}`);
    
    // 5. 測試模式下自動執行
    if (params.context && params.context.test_mode === true) {
      Logger.log(`P1 V8.14：測試模式，自動執行 Step 2`);
      
      // 輪詢 Step 2 結果
      const maxWaitTime = 120000;
      const pollInterval = 2000;
      const startTime = Date.now();
      
      while (Date.now() - startTime < maxWaitTime) {
        const m0Result_Step2 = getM0JobResult(jobId_Step2);
        
        if (m0Result_Step2 && m0Result_Step2.output) {
          Logger.log(`P1 V8.14：Step 2 執行完成`);
          
          // 處理 Step 2 結果
          return P1_ProcessStep2Result(jobId_Step2, m0Result_Step2, step1Result, params);
        }
        
        try {
          M0_Execute();
        } catch (e) {
          Logger.log(`P1 V8.14：調用 M0_Execute() 時發生錯誤：${e.message}`);
        }
        
        Utilities.sleep(pollInterval);
      }
      
      throw new Error("P1 Step 2 執行超時");
    }
    
    return {
      status: "SUBMITTED",
      job_id_step1: step1Result.job_id,
      job_id_step2: jobId_Step2,
      message: "P1 Step 2（結構分級）已提交到 M0，請執行 M0_Execute() 處理"
    };
    
  } catch (error) {
    Logger.log(`P1 V8.14：執行 Step 2 失敗：${error.message}`);
    throw error;
  }
}

/**
 * 從表格讀取 Flash 提取的財報資料
 * @param {Array} companyPool - 公司池清單
 * @return {Object} 財報資料 { ticker: { p1_evidence, p2_evidence, p3_evidence } }
 */
function loadFinancialReportExtractions(companyPool) {
  const financialData = {};
  
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName("Phase1_Company_Pool");
    
    if (!sheet || sheet.getLastRow() <= 1) {
      Logger.log(`P1 V8.14：Phase1_Company_Pool 表格不存在或沒有數據`);
      return financialData;
    }
    
    const dataRange = sheet.getDataRange();
    const rows = dataRange.getValues();
    const headers = rows[0];
    const tickerCol = headers.indexOf("Company_Code");
    const marketCol = headers.indexOf("Market");
    const p1Col = headers.indexOf("P1_Industry_Evidence_JSON");
    const p2Col = headers.indexOf("P2_Financial_Evidence_JSON");
    const p3Col = headers.indexOf("P3_Technical_Evidence_JSON");
    
    if (tickerCol === -1 || marketCol === -1) {
      Logger.log(`P1 V8.14：找不到必要的欄位`);
      return financialData;
    }
    
    // 建立 ticker+market 的索引
    const companyMap = {};
    for (const company of companyPool) {
      const key = `${company.ticker}_${company.market}`;
      companyMap[key] = company;
    }
    
    // 讀取表格中的提取資料
    for (let i = 1; i < rows.length; i++) {
      const ticker = rows[i][tickerCol];
      const market = rows[i][marketCol];
      const key = `${ticker}_${market}`;
      
      if (companyMap[key]) {
        try {
          const p1Json = p1Col !== -1 && rows[i][p1Col] ? 
            (typeof rows[i][p1Col] === 'string' ? JSON.parse(rows[i][p1Col]) : rows[i][p1Col]) : [];
          const p2Json = p2Col !== -1 && rows[i][p2Col] ? 
            (typeof rows[i][p2Col] === 'string' ? JSON.parse(rows[i][p2Col]) : rows[i][p2Col]) : [];
          const p3Json = p3Col !== -1 && rows[i][p3Col] ? 
            (typeof rows[i][p3Col] === 'string' ? JSON.parse(rows[i][p3Col]) : rows[i][p3Col]) : [];
          
          financialData[key] = {
            p1_industry_evidence: p1Json,
            p2_financial_evidence: p2Json,
            p3_technical_evidence: p3Json
          };
        } catch (e) {
          Logger.log(`P1 V8.14：解析 ${ticker} (${market}) 的提取資料失敗：${e.message}`);
        }
      }
    }
    
    Logger.log(`P1 V8.14：已讀取 ${Object.keys(financialData).length} 檔公司的財報提取資料`);
    return financialData;
    
  } catch (error) {
    Logger.log(`P1 V8.14：讀取財報提取資料失敗：${error.message}`);
    return financialData;
  }
}

/**
 * 構建 P1 Step 2 Prompt（結構分級）
 * @param {Array} companyPool - Step 1 生成的公司池
 * @param {Object} financialReportData - Flash 提取的財報資料
 * @param {Object} p0Output - P0 輸出
 * @param {Object} p0_5Output - P0.5 輸出
 * @param {Object} p0_7Output - P0.7 輸出
 * @return {string} Prompt 內容
 */
function buildP1Step2Prompt(companyPool, financialReportData, p0Output, p0_5Output, p0_7Output) {
  return `
## 🏢 P1 Step 2：結構分級與產業鏈定位（Structural Tiering & Chain Positioning）

**你的角色**：結構分析師（使用 Gemini Pro 3.0）

**你的任務**：
1. 檢視 Step 1 的股票池和 Flash 提取的財報資料
2. 將公司排入產業鏈正確的上中下游/互補/替代位置
3. 剔除完全無關的公司並說明理由
4. 主動獵殺舊技術龍頭（標記為 Tier X）
5. 按 Tier S/A/B/X 進行結構分級
6. 分析受益/受害機制

---

## ⚠️ 重要：職權邊界

**✅ 你可以做**：
- 檢視 Step 1 的股票池和 Flash 提取的財報資料（P1_Industry_Evidence, P2_Financial_Evidence, P3_Technical_Evidence）
- **將公司排入產業鏈正確位置**（上中下游/互補/替代）
- **剔除完全無關的公司**並說明理由
- **主動獵殺舊技術龍頭**（根據 P0 的技術替代路徑，找出提供舊技術的主流公司，標記為 Tier X）
- 按 Tier S/A/B/X 進行結構分級
- 分析受益/受害機制
- 使用業務結構佔比（Revenue Exposure / Mix）判斷「純度」

**❌ 絕對禁止**：
- ❌ 使用財務績效數據（EPS/成長率/毛利率數字）作為分級依據
- ❌ 使用估值（P/E、FPE、PEG）作為證據
- ❌ 使用技術分析（均線、支撐壓力）作為證據
- ❌ 使用股價漲跌證明地位
- ❌ 改寫 P0 主敘事或加入新宏觀論述

**P1 Step 2 負責分析、定位、分級，不負責資料蒐集**

---

## 📥 輸入：Step 1 的股票池 + Flash 提取的財報資料

### Step 1 生成的公司池
${JSON.stringify(companyPool, null, 2)}

### Flash 提取的財報資料（P1/P2/P3 三欄位）
**注意**：以下資料是 Flash 從各公司最新三季財報中提取的原文段落，已按 P1/P2/P3 分類。

每個公司都有以下結構：
- \`p1_industry_evidence\`: 產業定位相關段落（Business Description, Revenue Mix, Supply Chain, Competition, R&D, Capacity）
- \`p2_financial_evidence\`: 財務相關段落（Profitability, Growth, Balance Sheet, Cash Flow, Guidance, Risk Factors）
- \`p3_technical_evidence\`: 股權結構相關段落（Shareholding, Dilution, Capital Actions, Dividends）

**你必須使用這些提取的資料進行分析，不得自行搜尋其他資料。**

**財報提取資料（按公司索引）**：
${Object.keys(financialReportData).length > 0 ? 
  Object.entries(financialReportData).map(([key, data]) => {
    const [ticker, market] = key.split('_');
    return `\n**${ticker} (${market})**：
- P1_Industry_Evidence: ${data.p1_industry_evidence?.length || 0} 筆段落
- P2_Financial_Evidence: ${data.p2_financial_evidence?.length || 0} 筆段落
- P3_Technical_Evidence: ${data.p3_technical_evidence?.length || 0} 筆段落
${JSON.stringify(data, null, 2)}`;
  }).join('\n\n') : 
  '**注意**：部分公司可能尚未完成財報提取，請根據可用的資料進行分析。'}

### P0 輸出（必然位置表）
${JSON.stringify(p0Output, null, 2)}

### P0.5 輸出（產業鏈地圖）
${JSON.stringify(p0_5Output, null, 2)}

### P0.7 輸出（系統動力學分析）
${JSON.stringify(p0_7Output, null, 2)}

---

## 🎯 你的分析任務

### **任務 1：產業鏈位置定位與篩選**

針對 Step 1 生成的每個公司：

1. **讀取 Flash 提取的 P1_Industry_Evidence**：
   - 根據 Business Description 和 Supply Chain Role，判斷公司在產業鏈的位置
   - 將公司排入正確的上中下游/互補/替代位置
   - 對應到 P0.5 產業鏈地圖的具體節點

2. **剔除完全無關的公司**：
   - 如果 Flash 提取的資料顯示公司與該產業完全無關，必須剔除
   - 必須說明剔除理由（例如：業務描述不符、無相關產品/服務）

3. **主動獵殺舊技術龍頭**：
   - 根據 P0 的技術替代路徑（例如光取代銅），**主動搜尋「目前提供舊技術的主流公司」**
   - 讀取 Flash 提取的資料，確認該公司是否主要提供舊技術
   - 將其標記為 Tier X 候選，並說明理由

### **任務 2：結構分級（Tier S/A/B/X）**

針對通過任務 1 篩選的公司，進行結構分級：

#### **Tier S：核心瓶頸/不可取代（Kingmaker）**

定義：產業要噴，這家公司幾乎必吃最大肉，且難以被替代。

滿足以下至少 2 條（越多越 S）：
- **Choke Point**：位於 P0.5 產業鏈地圖的瓶頸節點（關鍵製程/材料/設備/標準）
- **Pricing Power**：具備訂價權（供需缺口時能主導價格或配額）
- **Low Substitutability**：替代成本高、驗證週期長（≥ 12–24 個月）
- **Structural Gatekeeper**：若缺貨，整條鏈會停擺或延遲
- **P0.7 對齊**：其受益機制在當前週期位置（Early/Mid/Late）仍成立

**注意**：S 可以是受益者，也可以是「危險節點」（例如 Late 時的泡沫核心），但若是風險核心需額外標記 risk_flag。

#### **Tier A：高連動受益/次核心（Contender）**

定義：高度吃到紅利，但有競爭者或可替代，或受制於上游。

滿足至少 1–2 條：
- **High Beta to Thesis**：需求成長會直接拉動訂單/出貨（但不掌控價格）
- **Competitive Field**：2–5 家競爭者，市占會輪動
- **Capacity Follower**：產能擴張受制於上游或設備交期
- **P0.7 Window-sensitive**：只有在某個窗口內（例如 Mid）最受益

#### **Tier B：順風受益/邊緣紅利（Beneficiary）**

定義：產業好它會跟漲，但不是決定性節點，利潤可能被上游/下游吃掉。

典型特徵：
- **Indirect Beneficiary**：需求外溢帶動（例如 DRAM 因 HBM 擠壓產能而漲）
- **Low Moat**：產品同質化，容易被比價
- **Margin Taker**：缺乏訂價權、毛利受擠壓（注意：這是結構描述，不是財務分析）
- **Narrative-driven**：較容易被題材帶動，但缺乏結構護城河

#### **Tier X：結構性受害者（Victim/Squeezed）**

定義：產業紅利來臨時，這類公司反而被擠壓、被替代、或被重新分配利潤。

至少符合 1 條：
- **Margin Squeeze**：上游漲價或下游砍價，利潤被壓縮
- **Demand Substitution**：替代節點成熟，需求被轉移
- **Capex Burden**：被迫投入大量資本，但回收期長且定價權不在自己
- **Regulatory/Policy Drag**：政策/法規導致成本上升或市場萎縮
- **P0.7 Failure Mode Exposure**：正好暴露於動力學的失敗模式（例如供給過剩時最先死）

**注意**：X 不是「垃圾公司」，而是「在本產業劇本下的受害者」。你必須主動獵殺的舊技術龍頭應該標記為 Tier X。

---

## 📤 輸出格式

請按照以下 JSON 格式輸出：

{
  "tiered_companies": [
    {
      "ticker": "AAPL",
      "company_name": "Apple Inc.",
      "market": "US",
      "theme_id": "THEME_001",
      "subtheme_id": "SUBTHEME_001",
      "supply_chain_position": "Upstream / Midstream / Downstream / Complementary / Victim",
      "p0_5_chain_map_node_id": "UPSTREAM_001",
      "is_relevant": true,
      "exclusion_reason": null,
      "is_old_tech_leader": false,
      "old_tech_leader_reason": null,
      "tier": "S / A / B / X",
      "tier_reason": "分級理由（必須基於結構性特徵，不可用財務數據）",
      "benefit_mechanism": "受益機制描述（Tier S/A/B 使用）",
      "detriment_mechanism": "受害機制描述（Tier X 使用）",
      "revenue_exposure": {
        "exposure_percentage": 85.5,
        "exposure_description": "AI 相關業務佔總營收 85.5%"
      },
      "confidence_level": 0.9,
      "evidence_sufficiency": "High / Medium / Low"
    },
    {
      "ticker": "IRRELEVANT_001",
      "company_name": "無關公司",
      "market": "US",
      "theme_id": "THEME_001",
      "subtheme_id": "SUBTHEME_001",
      "is_relevant": false,
      "exclusion_reason": "業務描述顯示該公司主要從事其他產業，與本主題無關",
      "tier": null
    }
  ],
  "summary": {
    "total_companies_from_step1": 25,
    "relevant_companies": 23,
    "excluded_companies": 2,
    "old_tech_leaders_found": 1,
    "tier_s_count": 3,
    "tier_a_count": 8,
    "tier_b_count": 12,
    "tier_x_count": 2
  }
}

---

## ⚠️ 輸出要求

1. **必須先進行產業鏈位置定位與篩選**：
   - 讀取 Flash 提取的 P1_Industry_Evidence，判斷公司在產業鏈的位置
   - 剔除完全無關的公司，說明剔除理由
   - 主動獵殺舊技術龍頭，標記為 Tier X

2. **分級依據必須是結構性特徵**：
   - ✅ 允許：Choke Point、Pricing Power、Substitutability、供應鏈位置、P0.7 週期風險
   - ✅ 允許：業務結構佔比（Revenue Exposure / Mix）判斷「純度」
   - ✅ 允許：使用 Flash 提取的 P1_Industry_Evidence 進行產業鏈定位
   - ❌ 禁止：EPS/成長率/毛利率數字、估值、技術分析、股價

3. **必須分析受益/受害機制**：
   - 每家公司至少 1 條機制描述
   - Tier S/A/B 使用 benefit_mechanism
   - Tier X 使用 detriment_mechanism

4. **必須使用 Flash 提取的資料**：
   - 優先使用 P1_Industry_Evidence 進行產業鏈定位
   - 可以使用 P2_Financial_Evidence 判斷「純度」（Revenue Exposure）
   - 不得自行搜尋其他資料

5. **必須對齊 P0/P0.5/P0.7**：
   - 不得改寫 P0 主敘事
   - 不得加入新宏觀論述
   - 只能新增：公司與節點的映射、受益/受害機制、分級理由
`;
}

/**
 * 處理 P1 Step 2 結果
 * @param {string} jobId - Job ID
 * @param {Object} m0Result - M0 執行結果
 * @param {Object} step1Result - Step 1 處理結果
 * @param {Object} params - 原始執行參數
 * @return {Object} P1 最終處理結果
 */
function P1_ProcessStep2Result(jobId, m0Result, step1Result, params) {
  try {
    Logger.log(`P1 V8.14：處理 Step 2 結果，jobId=${jobId}`);
    
    const executorOutput = m0Result.executor_output || m0Result.output || {};
    const auditorOutput = m0Result.auditor_output || {};
    
    // 解析輸出
    let step2Output = {};
    if (typeof executorOutput === 'string') {
      try {
        let jsonString = executorOutput.trim();
        if (jsonString.startsWith('```json')) {
          jsonString = jsonString.replace(/^```json\s*/, '').replace(/\s*```$/, '');
        } else if (jsonString.startsWith('```')) {
          jsonString = jsonString.replace(/^```\s*/, '').replace(/\s*```$/, '');
        }
        step2Output = JSON.parse(jsonString);
      } catch (e) {
        Logger.log(`P1 V8.14：無法解析 Step 2 executorOutput：${e.message}`);
        step2Output = executorOutput;
      }
    } else {
      step2Output = executorOutput;
    }
    
    // 驗證分級結果結構
    if (!step2Output.tiered_companies || !Array.isArray(step2Output.tiered_companies)) {
      throw new Error("Step 2 輸出缺少 tiered_companies 欄位或格式不正確");
    }
    
    Logger.log(`P1 V8.14：Step 2 完成分級，共 ${step2Output.tiered_companies.length} 檔公司`);
    
    // 生成 P1 最終輸出（使用 Tier 系統）
    const p1Output = {
      tiered_companies: step2Output.tiered_companies,
      summary: step2Output.summary || {},
      auditor_review: auditorOutput.audit_review || auditorOutput.review || null,
      confidence_level: auditorOutput.confidence || auditorOutput.confidence_level || 0.7,
      timestamp: new Date().toISOString()
    };
    
    // 保存到 Phase1_Company_Pool（使用 Tier 系統）
    const poolResults = saveToP1CompanyPool(p1Output);
    
    // 保存快照
    const snapshot = saveP1Snapshot({
      job_id: jobId,
      trigger: params.trigger || "QUARTERLY",
      p1_output: p1Output,
      pool_results: poolResults,
      p0_snapshot_id: params.p0_snapshot_id,
      p0_5_snapshot_id: params.p0_5_snapshot_id,
      p0_7_snapshot_id: params.p0_7_snapshot_id,
      changes: compareWithPreviousSnapshotP1(p1Output)
    });
    
    // 檢查是否需要觸發下游
    if (snapshot.changes && snapshot.changes.has_changes) {
      triggerDownstreamPhasesP1("P1", snapshot);
    }
    
    Logger.log(`P1 V8.14：處理完成，snapshot_id=${snapshot.snapshot_id}`);
    
    return {
      status: "COMPLETED",
      snapshot_id: snapshot.snapshot_id,
      p1_output: p1Output,
      pool_results: poolResults,
      changes: snapshot.changes
    };
    
  } catch (error) {
    Logger.log(`P1 V8.14：處理 Step 2 結果失敗：${error.message}`);
    throw error;
  }
}

// ==========================================
// 保存到 Phase1_Company_Pool（Tier 系統）
// ==========================================

/**
 * 保存到 Phase1_Company_Pool（使用 Tier 系統）
 * @param {Object} p1Output - P1 輸出
 * @return {Object} 保存結果
 */
function saveToP1CompanyPool(p1Output) {
  const results = {
    companies_saved: 0,
    errors: []
  };
  
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName("Phase1_Company_Pool");
    
    if (!sheet) {
      sheet = ss.insertSheet("Phase1_Company_Pool");
      sheet.appendRow(PHASE1_COMPANY_POOL_SCHEMA.headers);
      sheet.setFrozenRows(1);
    }
    
    const headers = PHASE1_COMPANY_POOL_SCHEMA.headers;
    const now = new Date();
    
    for (const company of p1Output.tiered_companies || []) {
      try {
        // 檢查是否已存在（根據 Theme_ID + Company_Code）
        const existingRow = findExistingRowInCompanyPool(sheet, company.theme_id, company.ticker);
        
        // 讀取 Flash 提取的資料（如果已存在）
        const key = `${company.ticker}_${company.market}`;
        const extractedData = loadFinancialReportExtractions([company])[key] || {};
        
        // 按照 PHASE1_COMPANY_POOL_SCHEMA.headers 的順序構建 rowData
        const rowData = [
          company.theme_id || "",  // Theme_Track
          company.theme_id || "",  // Theme_ID
          company.subtheme_id || "",  // Subtheme_ID
          company.ticker || "",  // Company_Code
          company.company_name || "",  // Company_Name
          company.market || "",  // Market
          company.p0_5_chain_map_node_id || "",  // Primary_Technology_or_Node
          company.tier || "",  // Tier
          company.tier_reason || "",  // Tier_Reason
          company.benefit_mechanism || "",  // Benefit_Mechanism
          company.detriment_mechanism || "",  // Detriment_Mechanism
          company.revenue_exposure?.exposure_percentage || "",  // Revenue_Exposure
          "",  // Financial_Report_Proof（已移至 Flash 提取結果）
          "SEC/MOPS/EDINET",  // Financial_Report_Source
          company.is_relevant === false ? "EXCLUDED" : (extractedData.p1_industry_evidence ? "EXTRACTED" : "PENDING"),  // Financial_Report_Status
          JSON.stringify(extractedData.p1_industry_evidence || []),  // P1_Industry_Evidence_JSON
          JSON.stringify(extractedData.p2_financial_evidence || []),  // P2_Financial_Evidence_JSON
          JSON.stringify(extractedData.p3_technical_evidence || []),  // P3_Technical_Evidence_JSON
          extractedData.p1_industry_evidence ? "EXTRACTED" : "PENDING",  // Financial_Report_Extraction_Status
          company.supply_chain_position || "",  // Supply_Chain_Position
          company.p0_5_chain_map_node_id || "",  // P0_5_Chain_Map_Node
          "",  // P0.7_Loop_Dominance（從 P0.7 獲取）
          "",  // P0.7_Time_Position（從 P0.7 獲取）
          "",  // P0.7_Leveraged_Role_Type（從 P0.7 獲取）
          company.confidence_level || 0.7,  // Confidence_Level
          company.evidence_sufficiency || "Medium",  // Evidence_Sufficiency
          "P1_V8.14",  // Source_Type
          "1.0",  // Phase_Version
          "",  // Notes
          now,  // created_at
          now   // updated_at
        ];
        
        if (existingRow > 0) {
          // 更新現有記錄
          for (let col = 0; col < rowData.length && col < headers.length; col++) {
            sheet.getRange(existingRow, col + 1).setValue(rowData[col]);
          }
        } else {
          // 新增記錄
          sheet.appendRow(rowData);
          results.companies_saved++;
        }
      } catch (error) {
        Logger.log(`保存公司到 Phase1_Company_Pool 失敗：${error.message}`);
        results.errors.push(error.message);
      }
    }
    
    Logger.log(`P1 V8.14：已保存 ${results.companies_saved} 筆公司到 Phase1_Company_Pool`);
    return results;
    
  } catch (error) {
    Logger.log(`保存到 Phase1_Company_Pool 失敗：${error.message}`);
    results.errors.push(error.message);
    return results;
  }
}

/**
 * 在 Phase1_Company_Pool 中查找現有記錄
 * @param {Sheet} sheet - 表格
 * @param {string} themeId - Theme ID
 * @param {string} ticker - 股票代號
 * @return {number} 行號（1-based），如果不存在則返回 -1
 */
function findExistingRowInCompanyPool(sheet, themeId, ticker) {
  const dataRange = sheet.getDataRange();
  const rows = dataRange.getValues();
  const headers = rows[0];
  
  const themeIdCol = headers.indexOf("Theme_ID");
  const tickerCol = headers.indexOf("Company_Code");
  
  if (themeIdCol === -1 || tickerCol === -1) {
    return -1;
  }
  
  for (let i = 1; i < rows.length; i++) {
    if (rows[i][themeIdCol] === themeId && rows[i][tickerCol] === ticker) {
      return i + 1;  // 1-based
    }
  }
  
  return -1;
}

// ==========================================
// 輔助函數
// ==========================================

/**
 * 獲取 P0.5 快照（根據 snapshot_id）
 * @param {string} snapshotId - 快照 ID
 * @return {Object|null} P0.5 快照
 */
function getP0_5SnapshotById(snapshotId) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName("P0_5__SNAPSHOT");
    
    if (!sheet || sheet.getLastRow() <= 1) {
      return null;
    }
    
    const dataRange = sheet.getDataRange();
    const rows = dataRange.getValues();
    const headers = rows[0];
    const getColIndex = (headerName) => headers.indexOf(headerName);
    const snapshotIdCol = getColIndex("snapshot_id");
    
    for (let i = 1; i < rows.length; i++) {
      if (rows[i][snapshotIdCol] === snapshotId) {
        const row = rows[i];
        return {
          snapshot_id: row[snapshotIdCol],
          created_at: row[getColIndex("created_at")] || null,
          trigger: row[getColIndex("trigger")] || null,
          p0_5_output_json: row[getColIndex("p0_5_output_json")] || null,
          p0_snapshot_id: row[getColIndex("p0_snapshot_id")] || null,
          industry_chain_map_json: row[getColIndex("industry_chain_map_json")] || null,
          supply_chain_risk_json: row[getColIndex("supply_chain_risk_json")] || null,
          changes_json: row[getColIndex("changes_json")] || null,
          version: row[getColIndex("version")] || "V8.14"
        };
      }
    }
    
    return null;
  } catch (error) {
    Logger.log(`獲取 P0.5 快照失敗：${error.message}`);
    return null;
  }
}

/**
 * 獲取最新的 P0.5 快照
 * @return {Object|null} P0.5 快照
 */
function getLatestP0_5Snapshot() {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName("P0_5__SNAPSHOT");
    
    if (!sheet || sheet.getLastRow() <= 1) {
      return null;
    }
    
    const dataRange = sheet.getDataRange();
    const rows = dataRange.getValues();
    const headers = rows[0];
    const getColIndex = (headerName) => headers.indexOf(headerName);
    
    // 返回最後一行（最新的快照）
    const lastRow = rows[rows.length - 1];
    
    return {
      snapshot_id: lastRow[getColIndex("snapshot_id")],
      created_at: lastRow[getColIndex("created_at")] || null,
      trigger: lastRow[getColIndex("trigger")] || null,
      p0_5_output_json: lastRow[getColIndex("p0_5_output_json")] || null,
      p0_snapshot_id: lastRow[getColIndex("p0_snapshot_id")] || null,
      industry_chain_map_json: lastRow[getColIndex("industry_chain_map_json")] || null,
      supply_chain_risk_json: lastRow[getColIndex("supply_chain_risk_json")] || null,
      changes_json: lastRow[getColIndex("changes_json")] || null,
      version: lastRow[getColIndex("version")] || "V8.14"
    };
  } catch (error) {
    Logger.log(`獲取最新 P0.5 快照失敗：${error.message}`);
    return null;
  }
}
