/**
 * 📈 P3: 技術分析 - 數據收集模組
 * 
 * 負責從外部權威數據源收集技術指標
 * 優先使用外部計算好的指標，不自己計算
 * 
 * @version SSOT V7.1
 * @date 2025-01-11
 */

// ==========================================
// 外部技術數據收集（優先使用權威數據源）
// ==========================================

/**
 * 從外部權威數據源收集技術指標（優先使用，不自己計算）
 * ⭐ 所有數據都由程式從白名單數據源獲取，不讓 AI 自己去找
 * 
 * @param {Array} phase2Output - P2 輸出數據
 * @returns {Object} technicalData - 技術指標數據（包含歷史 OHLCV 數據）
 */
function collectTechnicalDataFromExternalSources(phase2Output) {
  const technicalData = {};
  
  for (const output of phase2Output) {
    const ticker = output.company_code || output.ticker;
    const market = output.market || "US";
    
    if (!ticker) continue;
    
    try {
      // ========================================
      // Step 1: 讀取技術指標（由 P5 Daily 收集）
      // ========================================
      
      // 優先從 MARKET_INDICATORS_DAILY 表格讀取（由 P5 Daily 收集）
      let data = getTechnicalIndicatorsFromSheet(ticker);
      
      // 如果表格沒有數據，嘗試從外部數據源獲取
      if (!data || !data.rsi_14) {
        data = fetchTechnicalIndicatorsFromExternalSource(ticker, market);
      }
      
      // ========================================
      // Step 2: 讀取歷史 OHLCV 數據（由 P5 Daily 收集）
      // ⭐ 優先從 MARKET_OHLCV_DAILY 表格讀取（已持倉個股可以使用留存的資料）
      // ⭐ 如果數據不足，自動從 stooq.com 補充（通過 Cloud Function 代理，使用白名單）
      // ========================================
      
      let historicalOHLCV = null;
      try {
        // 獲取最近 240 天的歷史 OHLCV 數據（用於技術分析）
        // getHistoricalOHLCV 函數會：
        // 1. 優先從 MARKET_OHLCV_DAILY 表格讀取已保存的數據
        // 2. 如果數據不足，自動從 stooq.com 補充（通過 Cloud Function 代理）
        // 3. 合併數據（去重，保留表格中的最新數據）
        historicalOHLCV = getHistoricalOHLCV(ticker, 240, true);
        
        if (historicalOHLCV && historicalOHLCV.length > 0) {
          Logger.log(`P3：成功獲取 ${ticker} 歷史 OHLCV 數據（${historicalOHLCV.length} 天）`);
        } else {
          Logger.log(`P3：${ticker} 歷史 OHLCV 數據為空`);
        }
      } catch (ohlcvError) {
        Logger.log(`P3：獲取 ${ticker} 歷史 OHLCV 數據失敗：${ohlcvError.message}`);
        historicalOHLCV = null;
      }
      
      // ========================================
      // Step 3: 組合技術數據
      // ========================================
      
      technicalData[ticker] = {
        ticker: ticker,
        market: market,
        data_source: data ? data.source : "NONE",
        indicators: data ? data.indicators : null,
        historical_ohlcv: historicalOHLCV,  // ⭐ 歷史 OHLCV 數據（不同時間的）
        last_updated: data ? data.last_updated : null,
        // 保留舊的 ohlcv 欄位（向後兼容）
        ohlcv: historicalOHLCV && historicalOHLCV.length > 0 ? historicalOHLCV[historicalOHLCV.length - 1] : null
      };
      
    } catch (error) {
      Logger.log(`P3：收集 ${ticker} 技術數據失敗：${error.message}`);
      technicalData[ticker] = {
        ticker: ticker,
        market: market,
        data_source: "ERROR",
        error: error.message
      };
    }
  }
  
  return technicalData;
}

/**
 * 從表格讀取技術指標（由 P5 Daily 收集）
 * 
 * @param {string} ticker - 股票代碼
 * @returns {Object|null} - 技術指標數據或 null
 */
function getTechnicalIndicatorsFromSheet(ticker) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName("MARKET_INDICATORS_DAILY");
    
    if (!sheet || sheet.getLastRow() <= 1) {
      return null;
    }
    
    const dataRange = sheet.getDataRange();
    const rows = dataRange.getValues();
    const headers = rows[0];
    
    const tickerCol = headers.indexOf("ticker");
    const dateCol = headers.indexOf("date");
    
    if (tickerCol === -1 || dateCol === -1) {
      return null;
    }
    
    // 找到該 ticker 的最新數據
    let latestRow = null;
    let latestDate = null;
    
    for (let i = rows.length - 1; i >= 1; i--) {
      if (rows[i][tickerCol] === ticker) {
        const rowDate = rows[i][dateCol];
        if (!latestDate || rowDate > latestDate) {
          latestDate = rowDate;
          latestRow = rows[i];
        }
      }
    }
    
    if (!latestRow) {
      return null;
    }
    
    // 解析技術指標
    const indicators = {};
    headers.forEach((header, colIndex) => {
      if (header !== "ticker" && header !== "date" && header !== "created_at") {
        indicators[header] = latestRow[colIndex];
      }
    });
    
    return {
      source: "MARKET_INDICATORS_DAILY",
      indicators: indicators,
      date: latestDate,
      last_updated: latestDate
    };
    
  } catch (error) {
    Logger.log(`從表格讀取技術指標失敗：${error.message}`);
    return null;
  }
}

/**
 * 從外部數據源獲取技術指標（stooq.com 等權威數據源）
 * 
 * @param {string} ticker - 股票代碼
 * @param {string} market - 市場（US/TW/JP）
 * @returns {Object|null} - 技術指標數據或 null
 */
function fetchTechnicalIndicatorsFromExternalSource(ticker, market) {
  try {
    // 優先使用外部計算好的指標，不自己計算
    // stooq.com 提供 OHLCV 數據，但技術指標需要從其他來源獲取
    
    // 方案 1：嘗試從 M0 CSE 搜尋獲取技術指標（如果配置了相關 CSE）
    // 方案 2：從其他權威數據源獲取（如 Yahoo Finance API、Alpha Vantage 等）
    // 方案 3：如果沒有外部計算好的指標，返回 OHLCV 數據，讓 AI 分析
    
    // 目前先返回 OHLCV 數據結構，供後續擴展
    // 注意：實際技術指標（RSI、MACD等）應該由 P5 Daily 收集並存儲在 MARKET_INDICATORS_DAILY 表格中
    
    Logger.log(`P3：嘗試從外部數據源獲取 ${ticker} 技術指標（市場：${market}）`);
    
    // 暫時返回 null，因為技術指標應該由 P5 Daily 收集
    // 如果 P5 Daily 沒有數據，說明系統尚未運行 P5 Daily，需要先運行 P5 Daily
    Logger.log(`P3：${ticker} 的技術指標應由 P5 Daily 收集，請先運行 P5 Daily`);
    
    return null;
  } catch (error) {
    Logger.log(`P3：從外部數據源獲取 ${ticker} 技術指標失敗：${error.message}`);
    return null;
  }
}
