/**
 * 📊 P5 Weekly: Prompt 構建模組
 * 
 * 負責構建所有 P5 Weekly 相關的 AI Prompt：
 * - 宏觀世界觀分析 Prompt
 * - 個股策略分析 Prompt（帶 Batch 支持）
 * - 整合 Prompt
 * 
 * @version SSOT V7.1
 * @date 2025-01-12
 */

// ==========================================
// 宏觀世界觀分析 Prompt
// ==========================================

/**
 * 構建宏觀世界觀分析 Prompt
 * 
 * @param {Object} data - 數據
 * @param {Object} data.macroData - 宏觀數據
 * @param {Array} data.worldviewHistory - 歷史世界觀更新
 * @param {Array} data.learningLogHistory - 歷史學習日誌
 * @param {Object} data.weeklyMarketData - 本週市場數據
 * @returns {string} prompt - AI Prompt
 */
function buildWorldviewPrompt(data) {
  const {
    macroData = {},
    worldviewHistory = [],
    learningLogHistory = [],
    weeklyMarketData = {},
    smartMoneyReport = {},  // ⭐ V8.0 新增：籌碼面週報
    sectorETFFlows = {},    // ⭐ V8.0 新增：Sector ETF Flow
    rotationSignal = {},     // ⭐ V8.0 新增：Rotation Signal
    mag7Analysis = {}        // ⭐ V8.0 新增：Mag 7 集體表現分析
  } = data;
  
  return `
你是一位資深的宏觀經濟分析師，負責進行 Nuclear Project 的 P5 Weekly 宏觀世界觀分析。

## 任務目標

基於本週所有市場數據、宏觀數據、新聞和歷史世界觀，進行全面的宏觀世界觀分析：
1. **整合本週所有新聞快照和市場數據**：分析本週的宏觀世界財經觀
2. **與歷史世界觀對照**：與前一個月（4 週）的世界觀做連接與對照
3. **學習世界觀的變化**：識別世界觀的演變趨勢
4. **分析世界觀與市場反應的連結**：判斷世界觀與現實市場反應是相符、無關還是背離

## 本週宏觀數據

${JSON.stringify(macroData, null, 2)}

## 本週市場數據摘要

${JSON.stringify(weeklyMarketData, null, 2)}

## 歷史世界觀更新（最近 4 週）

${JSON.stringify(worldviewHistory.slice(0, 4), null, 2)}

## 歷史學習日誌（最近 4 週）

${JSON.stringify(learningLogHistory.slice(0, 4), null, 2)}

## 籌碼面週報 ⭐ V8.0 新增

${JSON.stringify(smartMoneyReport, null, 2)}

**重要**：籌碼面信號（BULLISH/NEUTRAL/BEARISH）應影響整體市場判斷。

## Sector ETF Flow 分析 ⭐ V8.0 新增

**Sector ETF Flow 數據**：
${JSON.stringify(sectorETFFlows, null, 2)}

**資金輪動信號（Rotation Signal）**：
${JSON.stringify(rotationSignal, null, 2)}

**重要**：
- 資金流入板塊（to_sectors）表示市場資金偏好
- 資金流出板塊（from_sectors）表示市場資金撤離
- Regime（RISK_ON/RISK_OFF/ROTATION/CRISIS）應整合到市場 Regime 判斷中

## Mag 7 集體表現分析 ⭐ V8.0 新增

**Mag 7 成員**：AAPL, MSFT, GOOGL, AMZN, NVDA, META, TSLA

**Mag 7 集體表現數據**：
${JSON.stringify(mag7Analysis, null, 2)}

**評分體系**：
- 每檔財報評分：+2（Beat + 指引上調）、+1（Beat + 持平）、0（符合）、-1（Miss + 持平）、-2（Miss + 下調）
- 總分範圍：-14 to +14

**Regime 映射規則**：
- **+10 to +14**：BULL_STRONG → U_macro 0.80，DEFCON 5
- **+5 to +9**：BULL_WEAK → U_macro 0.70，DEFCON 5
- **-4 to +4**：NEUTRAL → U_macro 0.60，DEFCON 4
- **-9 to -5**：BEAR_WEAK → U_macro 0.50，DEFCON 3
- **-14 to -10**：BEAR_STRONG → U_macro 0.30，DEFCON 1

**重要**：
- ⭐⭐⭐ **Mag 7 集體表現是市場 Regime 判斷的重要指標**，必須整合到 market_regime 判斷中
- ⭐⭐⭐ **Mag 7 總分應影響 u_macro_recommendation 的建議值**
- ⭐⭐⭐ **如果 Mag 7 總分 <= -10，應提高 risk_assessment.systemic_risk 等級，並建議啟動 DEFCON 1**
- 在財報季結束後（4-6 週）綜合評估，但每週都應更新最新財報結果

## 市場情緒指標 ⭐ V8.0 新增

**市場情緒指標數據**：
${JSON.stringify(weeklyMarketData.market_sentiment_indicators || {}, null, 2)}

**現有市場情緒指標**（從宏觀數據和衍生品數據中）：
- **VIX**（恐慌指數）：${macroData.indices?.VIX?.value || 'N/A'} - 反映市場恐慌程度
- **Put/Call Ratio**（看跌/看漲比率）：${weeklyMarketData.derivatives_summary?.avg_put_call_ratio || 'N/A'} - 反映期權市場情緒
- **Skew**（偏度指數）：${weeklyMarketData.derivatives_summary?.skew || 'N/A'} - 反映尾部風險

**新增市場情緒指標**：
- **FPE_B**（分析師共識 Forward P/E）：
  - 反映市場對個股的普遍看法（樂觀/中性/悲觀）
  - FPE_B 值越高，表示市場對該股票的估值預期越高（可能過度樂觀）
  - FPE_B 值越低，表示市場對該股票的估值預期越低（可能過度悲觀）
  - ⚠️ **重要**：FPE_B 與 FPE_A 的背離可能反映市場情緒與公司官方預期的差異
  - ⚠️ **重要**：FPE_B 的變化趨勢反映市場情緒變化

- **機構言行一致性分析（Institutional Sentiment）** ⭐ V8.6 新增：
  - **數據來源**：Yahoo Finance / Finviz 的機構評級歷史（Upgrades & Downgrades）
  - **核心邏輯**：結合「分析師說的話」與「市場實際反應（K線/量能）」來判斷是真訊號還是假動作
  - **sentiment_label** 解讀：
    - **STRONG_BULL / BULLISH**：機構升級 + 股價大漲 + 爆量 = 真利多（True Breakout），可順勢操作
    - **NEUTRAL**：機構動作與市場反應不一致，或無明顯趨勢
    - **BEARISH / STRONG_BEAR**：機構降級 + 股價重挫 + 爆量 = 真利空，應避開
  - **warnings** 解讀（⚠️ 關鍵）：
    - **誘多出貨（Bull Trap）**：機構 Upgrade 但股價不漲/下跌 → 主力在出貨，準備 P4.6 撤退
    - **誘空吃貨（Bear Trap）**：機構 Downgrade 但股價不跌/上漲 → 主力在吃貨，P3 準備進場
  - **戰略意義**：
    - ⚠️ **這些是「大眾看得到的風向」，不是付費頂級情報**
    - ⚠️ **重點是「反向解讀」與「共識檢驗」**：如果發現「高盛喊多 + 股價大跌」，這比任何技術指標都更準確地告訴我們：主力在跑了
    - ⚠️ **不要只看分析師說什麼，要看市場對他的話有什麼反應**

**重要**：
- ⭐⭐⭐ **所有市場情緒指標（VIX、Put/Call Ratio、Skew、FPE_B、機構評級）應綜合判斷市場 Regime**
- ⭐⭐⭐ **市場情緒指標的極端值應影響 risk_assessment.systemic_risk 等級**
- ⭐⭐⭐ **機構評級的 warnings（誘多/誘空）應優先於 sentiment_label 本身，因為它反映了「言行不一致」的異常訊號**
- ⭐ V8.9 新增：**多時間維度價格反應驗證**（短期 1-5 天、中期 7-15 天、長期 16-30 天）
  - 短期誘多但中期跟進 → 可能是短期騙線，但中長期趨勢成立
  - 短期誘空但中期跟進 → 可能是短期洗盤，但中長期趨勢成立
- ⭐ V8.9 新增：**機構可信度評分**（institutional_ratings_credibility）
  - 不同機構在不同時間維度的可信度不同
  - 可信度高的機構評級應給予更高權重
  - 可信度低的機構評級應謹慎參考
- ⭐⭐⭐ **市場情緒指標應整合到 market_regime 和 u_macro_recommendation 的判斷中**
- FPE_B 反映個股層面的市場情緒
- 當多個指標指向相同方向時（例如：VIX 高、Put/Call Ratio 高），市場情緒信號更強

## 輸出格式（必須是 JSON）

{
  "weekly_worldview": {
    "overall_status": "BULL/BEAR/TRANSITION",
    "key_themes": ["主題1", "主題2"],
    "market_regime": "BULL_STRONG/BULL_WEAK/RANGE/BEAR_WEAK/BEAR_STRONG/TRANSITION",
    "regime_confidence": 0.0-1.0,
    "macro_trends": {
      "commodities": "分析",
      "currencies": "分析",
      "bonds": "分析",
      "indices": "分析"
    }
  },
  "regime_transition": {
    "stay_probability": 0.0-1.0,
    "transition_to": "BULL_STRONG/BULL_WEAK/RANGE/BEAR_WEAK/BEAR_STRONG",
    "transition_probability": 0.0-1.0,
    "transition_reason": "轉換理由"
  },
  "u_macro_recommendation": {
    "value": 0.0-1.0,
    "reason": "U 調整理由（基於 Regime、Sector Rotation、市場寬度、Mag 7 集體表現等）",
    "previous_value": 0.0-1.0,
    "mag7_influence": "Mag 7 集體表現對 U 調整的影響說明"
  },
  "risk_assessment": {
    "systemic_risk": "LOW/MEDIUM/HIGH/CRITICAL",
    "primary_risk": "主要風險描述",
    "hedging_needed": true/false,
    "risk_factors": ["風險因子1", "風險因子2"]
  },
  "worldview_evolution": {
    "changes_from_last_week": "變化描述",
    "changes_from_last_month": "變化描述",
    "trend_direction": "UPWARD/DOWNWARD/STABLE"
  },
  "market_alignment": {
    "alignment_status": "ALIGNED/MISALIGNED/NEUTRAL",
    "alignment_analysis": "分析描述",
    "divergence_factors": ["因子1", "因子2"]
  },
  "key_conclusions": [
    {
      "conclusion": "結論描述",
      "confidence": 0.0-1.0,
      "supporting_evidence": ["證據1", "證據2"]
    }
  ]
}
`;
}

// ==========================================
// 個股策略分析 Prompt（Batch 版本）
// ==========================================

/**
 * 構建個股策略分析 Prompt（已在 24_P5_WEEKLY_STOCK_STRATEGY.js 中實現）
 * 
 * 此函數保留作為備用或擴展
 */
function buildStockStrategyPrompt(batch, context) {
  // 這個函數已經在 24_P5_WEEKLY_STOCK_STRATEGY.js 的 buildStockStrategyBatchPrompt 中實現
  // 這裡保留作為備用或擴展
  return buildStockStrategyBatchPrompt(batch, context);
}

// ==========================================
// 整合 Prompt（用於最終 AI 分析）
// ==========================================

/**
 * 構建 P5 Weekly 整合 Prompt（用於最終 AI 分析）
 * 
 * @param {Object} data - 數據
 * @param {Object} data.worldview - 世界觀分析結果
 * @param {Object} data.events - 事件分析結果
 * @param {Object} data.stockStrategies - 個股策略結果
 * @param {Object} data.allData - 所有收集的數據
 * @returns {string} prompt - AI Prompt
 */
function buildP5WeeklyIntegratedPrompt(data) {
  const {
    worldview = {},
    events = {},
    stockStrategies = {},
    allData = {},
    memoryPack = null  // ⭐ V8.13新增：Memory Pack（歷史學習經驗）
  } = data;
  
  // ⭐ V8.13新增：格式化Memory Pack為Prompt格式
  const memoryPackSection = memoryPack ? formatMemoryPackForPrompt(memoryPack) : "";
  
  return `
你是一位資深的市場分析師，負責進行 Nuclear Project 的 P5 Weekly 市場綜述。

## 任務目標

基於以下所有分析結果，進行全面的市場分析並生成最終策略：
1. **市場綜述**：整體市場狀態、趨勢、關鍵事件
2. **因果鏈分析**：識別市場變動的因果關係
3. **風險事件識別**：識別潛在風險事件
4. **衍生品策略調整**：根據市場狀態調整衍生品策略
5. **信念更新**：更新對市場的信念和預期
6. **U 調整**：建議 U（利用率）調整
7. **行動清單**：生成具體的行動建議
8. **觸發決策**：決定是否觸發其他 Phase

## 宏觀世界觀分析結果

${JSON.stringify(worldview, null, 2)}

## 事件監控與分析結果

${JSON.stringify(events, null, 2)}

## 市場情緒指標（⭐ V8.6 重要：包含機構言行一致性分析數據）

${JSON.stringify(allData.weekly_market_data?.market_sentiment_indicators || {}, null, 2)}

**重要**：
- ⭐⭐⭐ **機構評級的 warnings（誘多/誘空）應優先考慮**，因為它反映了「言行不一致」的異常訊號
- ⭐⭐⭐ **當多個標的出現「誘多出貨」警告時，建議降低 U 或觸發 P4 重新計算配置**
- ⭐⭐⭐ **當標的出現「誘空吃貨」警告且市場情緒穩定時，可能是進場機會，建議觸發 P3 重新分析**

## 個股策略分析結果（${Object.keys(stockStrategies).length} 檔股票）

${JSON.stringify(stockStrategies, null, 2)}

## 所有快照數據

P0 快照（產業工程學）：${allData.p0_snapshot ? "有數據" : "無"}
P0.7 快照（系統動力學）：${allData.p0_7_snapshot ? "有數據" : "無"}
P1 快照（公司池）：${allData.p1_snapshot ? "有數據" : "無"}
P2 快照（基本面）：${allData.p2_snapshot ? "有數據" : "無"}
P3 快照（技術面）：${allData.p3_snapshot ? "有數據" : "無"}
P4 快照（資金配置）：${allData.p4_snapshot ? "有數據" : "無"}
前一次 P5 Weekly 快照：${allData.previous_p5_weekly_snapshot ? "有數據" : "無"}

${memoryPackSection}

## 輸出格式（必須是 JSON）

{
  "market_analysis": {
    "overall_status": "BULL/BEAR/TRANSITION",
    "key_events": [],
    "trend_analysis": {},
    "market_regime": "BULL_STRONG/BULL_WEAK/BEAR_STRONG/BEAR_WEAK/TRANSITION"
  },
  "causality_chain": {
    "chains": [
      {
        "cause": "事件/數據",
        "effect": "影響",
        "confidence": 0.0-1.0
      }
    ]
  },
  "risk_events": [
    {
      "event": "風險事件描述",
      "severity": "LOW/MEDIUM/HIGH/CRITICAL",
      "probability": 0.0-1.0,
      "impact": "影響描述"
    }
  ],
  "derivatives_strategy_adjustment": {
    "recommendations": [],
    "hedging_ratio": 0.0-1.0,
    "options_strategy": {}
  },
  "belief_update": {
    "updated_beliefs": [],
    "confidence_changes": {},
    "worldview_integration": "世界觀整合分析"
  },
  "u_adjustment": {
    "recommended_u": 0.0-1.0,
    "reason": "調整理由（⭐ V8.6 重要：必須參考機構評級的 warnings 和 sentiment_label。如果多個標的出現「誘多出貨」警告，建議降低 U；如果出現「誘空吃貨」警告且市場情緒穩定，可考慮維持或略提高 U）",
    "trigger_condition": "觸發條件（例如：機構評級顯示誘多出貨訊號、市場 Regime 轉換等）",
    "institutional_sentiment_influence": "機構評級對本次 U 調整的影響說明（如果有）"
  },
  "action_list": [
    {
      "action": "行動描述",
      "priority": "HIGH/MEDIUM/LOW",
      "target": "目標標的/Phase",
      "institutional_sentiment_reference": "是否參考了機構評級數據（可選）"
    }
  ],
  "trigger_decisions": [
    {
      "trigger_phase": "P3/P4/P4.6",
      "reason": "觸發理由（⭐ V8.6/V8.9 重要：如果機構評級顯示「誘多出貨」警告，建議觸發 P3 重新分析該標的；如果多個標的出現誘多警告，建議觸發 P4 重新計算配置或 P4.6 緊急撤退。參考機構可信度評分，可信度高的機構評級警告應給予更高優先級）",
      "parameters": {
        "tickers": ["標的代碼（如果有）"],
        "institutional_sentiment_triggers": "機構評級觸發說明（例如：'AAPL 出現誘多出貨警告，建議 P3 重新分析'）",
        "institutional_credibility_reference": "參考的機構可信度評分（例如：'Goldman Sachs 短期可信度 0.6，中期可信度 0.8，本評級可信度較高'）"
      }
    }
  ],
  "stock_strategies_summary": {
    "total_stocks": ${Object.keys(stockStrategies).length},
    "increase_count": 0,
    "decrease_count": 0,
    "hold_count": 0,
    "exit_count": 0,
    "key_recommendations": []
  }
}
`;
}

/**
 * 格式化Memory Pack為Prompt格式 ⭐ V8.13新增
 * 
 * 將Memory Pack（三層記憶）格式化為可讀的prompt格式，供AI參考
 * 
 * @param {Object} memoryPack - Memory Pack
 * @returns {string} formattedMemoryPack - 格式化後的Memory Pack（用於prompt）
 */
function formatMemoryPackForPrompt(memoryPack) {
  if (!memoryPack) {
    return "";
  }
  
  let formatted = "\n## 📚 歷史學習經驗（Memory Pack）\n\n";
  formatted += "**重要**：這些歷史經驗僅供參考，AI需要根據當前情況判斷如何應用。不得直接複製歷史策略，必須根據當前市場狀態調整。\n\n";
  
  // Layer 1: Principles（長期原則）
  formatted += "### Layer 1: 長期原則（Principles）\n\n";
  if (memoryPack.layer_1_principles) {
    formatted += memoryPack.layer_1_principles + "\n\n";
  } else {
    formatted += "無（尚未建立長期原則）\n\n";
  }
  
  // Layer 2: Short-term Memory（最近4週）
  formatted += "### Layer 2: 短期記憶（最近4週）\n\n";
  if (memoryPack.layer_2_short_term && memoryPack.layer_2_short_term.length > 0) {
    for (const week of memoryPack.layer_2_short_term) {
      formatted += `**${week.period_id || '未知週期'}**：\n`;
      formatted += `- 摘要：${week.executive_summary || '無'}\n`;
      if (week.scorecard) {
        const accuracy = week.scorecard.accuracy !== undefined ? week.scorecard.accuracy : week.scorecard.directional_accuracy?.accuracy;
        const maxDrawdown = week.scorecard.max_drawdown || week.scorecard.max_drawdown_pct || 0;
        formatted += `- Scorecard：準度${((accuracy || 0) * 100).toFixed(1)}%，MDD ${maxDrawdown.toFixed(1)}%\n`;
      }
      if (week.top_lessons && week.top_lessons.length > 0) {
        formatted += `- 教訓：${week.top_lessons.join('; ')}\n`;
      }
      formatted += "\n";
    }
  } else {
    formatted += "無（尚未有足夠的歷史數據）\n\n";
  }
  
  // Layer 3: Contextual Recall（相似歷史案例）
  formatted += "### Layer 3: 相似歷史案例（Contextual Recall）\n\n";
  if (memoryPack.layer_3_contextual_recall && memoryPack.layer_3_contextual_recall.length > 0) {
    for (const case_ of memoryPack.layer_3_contextual_recall) {
      formatted += `**案例 ${case_.snapshot_id || '未知'}**（標籤：${(case_.tags || []).join(', ') || '無'}）：\n`;
      if (case_.executive_summary) {
        formatted += `- 摘要：${case_.executive_summary}\n`;
      }
      if (case_.lesson && case_.lesson.length > 0) {
        formatted += `- 教訓：${Array.isArray(case_.lesson) ? case_.lesson.join('; ') : case_.lesson}\n`;
      }
      if (case_.result_summary) {
        formatted += `- 結果：${case_.result_summary}\n`;
      }
      if (case_.evidence_ids && case_.evidence_ids.length > 0) {
        formatted += `- 證據ID：${case_.evidence_ids.join(', ')}\n`;
      }
      formatted += "\n";
    }
  } else {
    formatted += "無（尚未找到相似歷史案例）\n\n";
  }
  
  // 使用提醒
  formatted += "**使用提醒**：\n";
  formatted += "- 如果歷史案例顯示高風險（MDD>5%），需要提高風險控制\n";
  formatted += "- 如果歷史案例顯示成功經驗，可以參考但不可盲目複製\n";
  formatted += "- Principles是憲法級原則，必須遵守，但可以根據當前情況靈活應用\n\n";
  
  return formatted;
}

// ==========================================
// 舊版 Prompt（向後兼容）
// ==========================================

/**
 * 構建 P5 Weekly AI Prompt（舊版，向後兼容）
 * 
 * @param {Object} weeklyData - 本週市場數據
 * @param {Object} p2Snapshot - P2 快照
 * @param {Object} p3Snapshot - P3 快照
 * @param {Object} p4Snapshot - P4 快照
 * @param {Object} previousP5WeeklySnapshot - 上一週 P5 Weekly 快照
 * @returns {string} prompt - AI Prompt
 */
function buildP5WeeklyPrompt(weeklyData, p2Snapshot, p3Snapshot, p4Snapshot, previousP5WeeklySnapshot) {
  return `
你是一位資深的市場分析師，負責進行 Nuclear Project 的 P5 Weekly 市場綜述。

## 任務目標

基於本週市場數據和 P2/P3/P4 快照，進行全面的市場分析：
1. **市場綜述**：整體市場狀態、趨勢、關鍵事件
2. **因果鏈分析**：識別市場變動的因果關係
3. **風險事件識別**：識別潛在風險事件
4. **衍生品策略調整**：根據市場狀態調整衍生品策略
5. **信念更新**：更新對市場的信念和預期
6. **U 調整**：建議 U（利用率）調整
7. **行動清單**：生成具體的行動建議
8. **觸發決策**：決定是否觸發其他 Phase

## 本週市場數據

${JSON.stringify(weeklyData, null, 2)}

## P2/P3/P4 快照

P2 快照：${p2Snapshot ? JSON.stringify(p2Snapshot, null, 2) : "無"}
P3 快照：${p3Snapshot ? JSON.stringify(p3Snapshot, null, 2) : "無"}
P4 快照：${p4Snapshot ? JSON.stringify(p4Snapshot, null, 2) : "無"}

## 上一週 P5 Weekly 快照

${previousP5WeeklySnapshot ? JSON.stringify(previousP5WeeklySnapshot, null, 2) : "無（首次執行）"}

## 輸出格式（必須是 JSON）

{
  "market_analysis": {
    "overall_status": "BULL/BEAR/TRANSITION",
    "key_events": [],
    "trend_analysis": {},
    "market_regime": "BULL_STRONG/BULL_WEAK/BEAR_STRONG/BEAR_WEAK/TRANSITION"
  },
  "causality_chain": {
    "chains": [
      {
        "cause": "事件/數據",
        "effect": "影響",
        "confidence": 0.0-1.0
      }
    ]
  },
  "risk_events": [
    {
      "event": "風險事件描述",
      "severity": "LOW/MEDIUM/HIGH/CRITICAL",
      "probability": 0.0-1.0,
      "impact": "影響描述"
    }
  ],
  "derivatives_strategy_adjustment": {
    "recommendations": [],
    "hedging_ratio": 0.0-1.0,
    "options_strategy": {}
  },
  "belief_update": {
    "updated_beliefs": [],
    "confidence_changes": {}
  },
  "u_adjustment": {
    "recommended_u": 0.0-1.0,
    "reason": "調整理由（⭐ V8.6 重要：必須參考機構評級的 warnings 和 sentiment_label。如果多個標的出現「誘多出貨」警告，建議降低 U；如果出現「誘空吃貨」警告且市場情緒穩定，可考慮維持或略提高 U）",
    "trigger_condition": "觸發條件（例如：機構評級顯示誘多出貨訊號、市場 Regime 轉換等）",
    "institutional_sentiment_influence": "機構評級對本次 U 調整的影響說明（如果有）"
  },
  "action_list": [
    {
      "action": "行動描述",
      "priority": "HIGH/MEDIUM/LOW",
      "target": "目標標的/Phase",
      "institutional_sentiment_reference": "是否參考了機構評級數據（可選）"
    }
  ],
  "trigger_decisions": [
    {
      "trigger_phase": "P3/P4/P4.6",
      "reason": "觸發理由（⭐ V8.6/V8.9 重要：如果機構評級顯示「誘多出貨」警告，建議觸發 P3 重新分析該標的；如果多個標的出現誘多警告，建議觸發 P4 重新計算配置或 P4.6 緊急撤退。參考機構可信度評分，可信度高的機構評級警告應給予更高優先級）",
      "parameters": {
        "tickers": ["標的代碼（如果有）"],
        "institutional_sentiment_triggers": "機構評級觸發說明（例如：'AAPL 出現誘多出貨警告，建議 P3 重新分析'）",
        "institutional_credibility_reference": "參考的機構可信度評分（例如：'Goldman Sachs 短期可信度 0.6，中期可信度 0.8，本評級可信度較高'）"
      }
    }
  ]
}
`;
}
