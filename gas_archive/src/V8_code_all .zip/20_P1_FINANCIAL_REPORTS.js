/**
 * ⭐ V8.14 新增：P1 財報抓取模組
 * 
 * 實作財報抓取功能：
 * - 美股：SEC API（Ticker → CIK → 最新 10-K/10-Q HTML）
 * - 台股：MOPS（固定 URL 結構，抓取最新一季 PDF）
 * - 日股：EDINET/金融廳（固定索引，抓取最新 Annual/Quarterly）
 * - Gemini File API 整合（上傳 PDF，取得 fileUri）
 * 
 * @version V8.14
 * @date 2026-01-19
 */

// ==========================================
// 美股 SEC API 整合
// ==========================================

/**
 * 從 SEC API 獲取公司最新財報（10-K/10-Q HTML）
 * @param {string} ticker - 股票代號（例如：AAPL）
 * @return {Object|null} 財報資訊 { filing_url, filing_type, filing_date, business_description_html }
 */
function fetchSECFinancialReport(ticker) {
  try {
    // 1. Ticker → CIK 對照表（使用公開的 SEC 對照表）
    const cik = getCIKFromTicker(ticker);
    if (!cik) {
      Logger.log(`P1 財報：找不到 ${ticker} 的 CIK`);
      return null;
    }
    
    // 2. 呼叫 SEC company filings JSON API
    const filingsUrl = `https://data.sec.gov/submissions/CIK${cik.padStart(10, '0')}.json`;
    
    const response = UrlFetchApp.fetch(filingsUrl, {
      method: "GET",
      headers: {
        "User-Agent": "Nuclear Project P1 Financial Report Fetcher",
        "Accept": "application/json"
      },
      muteHttpExceptions: true
    });
    
    if (response.getResponseCode() !== 200) {
      Logger.log(`P1 財報：SEC API 呼叫失敗（${ticker}）：${response.getResponseCode()}`);
      return null;
    }
    
    const filingsData = JSON.parse(response.getContentText());
    
    // 3. 取得最新三筆 10-K 或 10-Q（最新三季）
    const recentFilings = filingsData.filings?.recent || {};
    const formTypes = recentFilings.form || [];
    const filingDates = recentFilings.filingDate || [];
    const accessionNumbers = recentFilings.accessionNumber || [];
    
    // 收集所有 10-K/10-Q，按日期排序
    const allFilings = [];
    for (let i = 0; i < formTypes.length; i++) {
      const formType = formTypes[i];
      if (formType === "10-K" || formType === "10-Q") {
        allFilings.push({
          form_type: formType,
          filing_date: filingDates[i],
          accession_number: accessionNumbers[i],
          index: i
        });
      }
    }
    
    // 按日期降序排序，取最新三筆
    allFilings.sort((a, b) => b.filing_date.localeCompare(a.filing_date));
    const latestThreeFilings = allFilings.slice(0, 3);
    
    if (latestThreeFilings.length === 0) {
      Logger.log(`P1 財報：找不到 ${ticker} 的 10-K/10-Q`);
      return null;
    }
    
    // 4. 處理最新三季財報
    const quarterlyReports = [];
    for (const filing of latestThreeFilings) {
      try {
        const accessionNo = filing.accession_number.replace(/-/g, '');
        const htmlUrl = `https://www.sec.gov/Archives/edgar/data/${cik}/${accessionNo}/${filing.form_type.toLowerCase()}-${filing.filing_date.replace(/-/g, '')}.txt`;
        
        // 下載 HTML
        const htmlContent = fetchSECFilingHTML(htmlUrl);
        
        quarterlyReports.push({
          filing_url: htmlUrl,
          filing_type: filing.form_type,
          filing_date: filing.filing_date,
          html_content: htmlContent,  // ⭐ 包含完整 HTML 內容
          source: "SEC"
        });
      } catch (error) {
        Logger.log(`P1 財報：下載 ${ticker} ${filing.filing_date} 財報失敗：${error.message}`);
      }
    }
    
    if (quarterlyReports.length === 0) {
      Logger.log(`P1 財報：無法下載 ${ticker} 的任何財報`);
      return null;
    }
    
    return {
      ticker: ticker,
      market: "US",
      quarterly_reports: quarterlyReports,  // ⭐ 包含三季財報，每季都有 html_content
      source: "SEC"
    };
    
  } catch (error) {
    Logger.log(`P1 財報：SEC 抓取失敗（${ticker}）：${error.message}`);
    return null;
  }
}

/**
 * 從 Ticker 獲取 CIK（使用 SEC 公開對照表）
 * @param {string} ticker - 股票代號
 * @return {string|null} CIK
 */
function getCIKFromTicker(ticker) {
  try {
    // 使用 SEC 公開的 Ticker-CIK 對照表
    // 注意：SEC 對照表很大，可以緩存或使用本地對照表
    // 這裡簡化處理，實際應該使用緩存機制
    
    const tickerToCIKUrl = "https://www.sec.gov/files/company_tickers.json";
    const response = UrlFetchApp.fetch(tickerToCIKUrl, {
      method: "GET",
      headers: {
        "User-Agent": "Nuclear Project P1 Financial Report Fetcher",
        "Accept": "application/json"
      },
      muteHttpExceptions: true
    });
    
    if (response.getResponseCode() !== 200) {
      Logger.log(`P1 財報：無法獲取 SEC Ticker-CIK 對照表`);
      return null;
    }
    
    const tickerMap = JSON.parse(response.getContentText());
    
    // tickerMap 格式：{ "0": { "cik_str": 320193, "ticker": "AAPL", "title": "Apple Inc." }, ... }
    for (const key in tickerMap) {
      if (tickerMap[key].ticker === ticker.toUpperCase()) {
        return tickerMap[key].cik_str.toString();
      }
    }
    
    return null;
  } catch (error) {
    Logger.log(`P1 財報：獲取 CIK 失敗（${ticker}）：${error.message}`);
    return null;
  }
}

/**
 * 下載 SEC Filing HTML
 * @param {string} htmlUrl - HTML URL
 * @return {string} HTML 內容
 */
function fetchSECFilingHTML(htmlUrl) {
  const response = UrlFetchApp.fetch(htmlUrl, {
    method: "GET",
    headers: {
      "User-Agent": "Nuclear Project P1 Financial Report Fetcher",
      "Accept": "text/html"
    },
    muteHttpExceptions: true
  });
  
  if (response.getResponseCode() !== 200) {
    throw new Error(`SEC HTML 下載失敗：${response.getResponseCode()}`);
  }
  
  return response.getContentText();
}

/**
 * 從 SEC HTML 中提取 Business Description（Item 1）
 * @param {string} htmlContent - HTML 內容
 * @return {string} Business Description 段落
 */
function extractBusinessDescriptionFromSECHTML(htmlContent) {
  // 簡化處理：使用正則表達式提取 Item 1 部分
  // 實際應該使用更精確的 HTML 解析
  
  const item1Match = htmlContent.match(/ITEM\s+1\.?\s*[:\-]?\s*BUSINESS[^]*?(?=ITEM\s+1A|ITEM\s+2|<\/DOCUMENT>)/i);
  if (item1Match) {
    // 移除 HTML 標籤（簡化處理）
    return item1Match[0].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  }
  
  return null;
}

// ==========================================
// 台股 MOPS 整合
// ==========================================

/**
 * 從 MOPS 獲取公司最新財報（固定 URL 結構）
 * @param {string} companyCode - 公司代號（例如：2330）
 * @return {Object|null} 財報資訊 { filing_url, filing_type, filing_date, pdf_blob }
 */
function fetchMOPSFinancialReport(companyCode) {
  try {
    // MOPS 固定 URL 結構：https://mops.twse.com.tw/server-java/t164sb01?step=1&CO_ID=2330&SYEAR=2025&SSEASON=4&REPORT_ID=C
    // 最新一季通常是最近一個完整季度
    
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth() + 1;  // 1-12
    
    // 判斷最新季度（Q1: 1-3, Q2: 4-6, Q3: 7-9, Q4: 10-12）
    let season = 4;  // 預設 Q4
    if (month >= 1 && month <= 3) {
      season = 1;  // Q1
    } else if (month >= 4 && month <= 6) {
      season = 2;  // Q2
    } else if (month >= 7 && month <= 9) {
      season = 3;  // Q3
    }
    
    // 嘗試最新季度，如果失敗則嘗試上一季度
    for (let attempt = 0; attempt < 2; attempt++) {
      const testSeason = attempt === 0 ? season : (season === 1 ? 4 : season - 1);
      const testYear = attempt === 0 ? year : (season === 1 ? year - 1 : year);
      
      const mopsUrl = `https://mops.twse.com.tw/server-java/t164sb01?step=1&CO_ID=${companyCode}&SYEAR=${testYear}&SSEASON=${testSeason}&REPORT_ID=C`;
      
      try {
        const response = UrlFetchApp.fetch(mopsUrl, {
          method: "GET",
          headers: {
            "User-Agent": "Mozilla/5.0"
          },
          muteHttpExceptions: true
        });
        
        if (response.getResponseCode() === 200) {
          const content = response.getContentText();
          
          // 檢查是否有 PDF 連結
          const pdfMatch = content.match(/href="([^"]*\.pdf[^"]*)"/i);
          if (pdfMatch) {
            const pdfUrl = pdfMatch[1].startsWith('http') ? pdfMatch[1] : `https://mops.twse.com.tw${pdfMatch[1]}`;
            
            // 下載 PDF
            const pdfResponse = UrlFetchApp.fetch(pdfUrl, {
              method: "GET",
              headers: {
                "User-Agent": "Mozilla/5.0"
              },
              muteHttpExceptions: true
            });
            
            if (pdfResponse.getResponseCode() === 200) {
              return {
                filing_url: pdfUrl,
                filing_type: `Q${testSeason}`,
                filing_date: `${testYear}-${String(testSeason * 3).padStart(2, '0')}-01`,
                pdf_blob: pdfResponse.getBlob(),
                source: "MOPS"
              };
            }
          }
        }
      } catch (error) {
        Logger.log(`P1 財報：MOPS 嘗試失敗（${companyCode}, ${testYear}Q${testSeason}）：${error.message}`);
      }
    }
    
    Logger.log(`P1 財報：找不到 ${companyCode} 的最新 MOPS 財報`);
    return null;
    
  } catch (error) {
    Logger.log(`P1 財報：MOPS 抓取失敗（${companyCode}）：${error.message}`);
    return null;
  }
}

// ==========================================
// 日股 EDINET/金融廳整合
// ==========================================

/**
 * 從 EDINET 獲取公司最新財報（固定索引）
 * @param {string} companyCode - 公司代號（例如：6758）
 * @return {Object|null} 財報資訊 { filing_url, filing_type, filing_date, pdf_blob }
 */
function fetchEDINETFinancialReport(companyCode) {
  try {
    // EDINET 固定索引：https://disclosure.edinet-fsa.go.jp/E01EW/BLMainController.jsp?uji.verb=W00Z1010initialize&uji.bean=ee.bean.parent.EECommonSearchBean&TARGET=BL01E00111
    // 需要根據公司代號查找最新財報
    
    // 簡化處理：使用 EDINET API 或固定 URL 結構
    // 實際應該使用 EDINET 的公開 API 或索引
    
    Logger.log(`P1 財報：EDINET 整合待實現（${companyCode}）`);
    return null;
    
  } catch (error) {
    Logger.log(`P1 財報：EDINET 抓取失敗（${companyCode}）：${error.message}`);
    return null;
  }
}

// ==========================================
// 統一財報抓取接口
// ==========================================

/**
 * 統一財報抓取接口（根據市場自動選擇）
 * @param {string} ticker - 股票代號
 * @param {string} market - 市場（US/TW/JP）
 * @return {Object|null} 財報資訊
 */
function fetchFinancialReport(ticker, market) {
  try {
    if (market === "US" || market === "美股") {
      return fetchSECFinancialReport(ticker);
    } else if (market === "TW" || market === "台股") {
      return fetchMOPSFinancialReport(ticker);
    } else if (market === "JP" || market === "日股") {
      return fetchEDINETFinancialReport(ticker);
    } else {
      Logger.log(`P1 財報：不支援的市場（${market}）`);
      return null;
    }
  } catch (error) {
    Logger.log(`P1 財報：統一抓取失敗（${ticker}, ${market}）：${error.message}`);
    return null;
  }
}

// ==========================================
// Gemini File API 整合（PDF 處理）
// ==========================================

/**
 * 上傳 PDF 到 Gemini File API 並提取 Business Description
 * @param {Blob} pdfBlob - PDF Blob
 * @param {string} fileName - 檔案名稱
 * @return {Object|null} { file_uri, business_description_text }
 */
function uploadPDFToGeminiAndExtract(pdfBlob, fileName) {
  try {
    // 1. 上傳到 Gemini File API
    const fileUri = uploadFileToGemini(pdfBlob, fileName);
    
    // 2. 使用 Gemini Flash 提取 Business Description
    const businessDescription = extractBusinessDescriptionFromGeminiFile(fileUri);
    
    // 3. 刪除 Gemini 檔案（釋放配額）
    deleteGeminiFile(fileUri);
    
    return {
      file_uri: fileUri,
      business_description_text: businessDescription
    };
    
  } catch (error) {
    Logger.log(`P1 財報：Gemini PDF 處理失敗：${error.message}`);
    return null;
  }
}

/**
 * 從 Gemini File 中提取 Business Description
 * @param {string} fileUri - Gemini File API URI
 * @return {string} Business Description 文字
 */
function extractBusinessDescriptionFromGeminiFile(fileUri) {
  const apiKey = getAPIKey("GOOGLE");
  const model = "gemini-3-flash-preview";
  
  const prompt = `你是一個文件閱讀器，負責從 PDF 文件中擷取「Business Description」或「業務描述」段落。

**你的任務**：
1. 閱讀這份 PDF 文件（可能是財報、年報或季報）
2. 找出文件中描述公司業務的段落（通常是「Business Description」、「業務描述」、「公司概況」等章節）
3. **只擷取原文段落，不要改寫、不要總結**

**擷取規則**：
1. **只擷取原文段落**：直接複製文件中描述公司業務的文字
2. **包含完整上下文**：如果業務描述分佈在多個段落，全部都要擷取
3. **標註頁數**：標註每個段落所在的頁數

**輸出格式（JSON）**：
{
  "business_description": "完整的業務描述原文段落（直接從文件中複製）",
  "page_numbers": [15, 16, 17],
  "source_section": "Business Description / 業務描述 / 公司概況"
}

**注意**：
- 不要進行任何分析、解釋或推理
- 只負責找到並複製業務描述的原文段落
`;
  
  const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
  
  const requestBody = {
    contents: [{
      parts: [
        { text: prompt },
        { file_data: { mime_type: "application/pdf", file_uri: fileUri } }
      ]
    }]
  };
  
  const response = UrlFetchApp.fetch(apiUrl, {
    method: "POST",
    headers: {
      "x-goog-api-key": apiKey,
      "Content-Type": "application/json"
    },
    payload: JSON.stringify(requestBody),
    muteHttpExceptions: true
  });
  
  if (response.getResponseCode() !== 200) {
    throw new Error(`Gemini 提取失敗：${response.getContentText()}`);
  }
  
  const result = JSON.parse(response.getContentText());
  const content = result.candidates[0].content.parts[0].text;
  
  // 解析 JSON
  let jsonMatch = content.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    const parsed = JSON.parse(jsonMatch[0]);
    return parsed.business_description || content;
  }
  
  return content;
}

/**
 * 上傳檔案到 Gemini File API（通用版本，支援 Blob）
 * @param {Blob} blob - 檔案 Blob
 * @param {string} fileName - 檔案名稱
 * @return {string} fileUri
 */
function uploadFileToGemini(blob, fileName) {
  const apiKey = getAPIKey("GOOGLE");
  
  // 手動組裝 multipart/related Payload
  const boundary = "----WebKitFormBoundary" + Utilities.getUuid();
  const metadata = JSON.stringify({ file: { display_name: fileName } });
  
  // 組裝 multipart/related body
  let body = "";
  body += `--${boundary}\r\n`;
  body += `Content-Type: application/json\r\n\r\n`;
  body += `${metadata}\r\n`;
  body += `--${boundary}\r\n`;
  body += `Content-Type: application/pdf\r\n\r\n`;
  body += Utilities.newBlob(blob.getBytes()).getDataAsString();
  body += `\r\n--${boundary}--\r\n`;
  
  // 上傳到 Gemini
  const uploadUrl = "https://generativelanguage.googleapis.com/upload/v1beta/files";
  const response = UrlFetchApp.fetch(uploadUrl, {
    method: "POST",
    headers: {
      "x-goog-api-key": apiKey,
      "Content-Type": `multipart/related; boundary=${boundary}`
    },
    payload: body,
    muteHttpExceptions: true
  });
  
  if (response.getResponseCode() !== 200) {
    throw new Error(`Gemini File API 上傳失敗：${response.getContentText()}`);
  }
  
  const result = JSON.parse(response.getContentText());
  return result.file.uri;
}

// ==========================================
// ⭐ V8.14 新增：財報下載與提取完整流程
// ==========================================

/**
 * P1 財報下載階段（統一入口）
 * @param {Array} companyPool - 公司池清單
 * @param {string} jobId - Job ID
 * @return {Object} 下載狀態
 */
function P1_FetchFinancialReports(companyPool, jobId) {
  const status = {
    us_companies: { total: 0, success: 0, failed: 0 },
    tw_companies: { total: 0, folders_created: 0, pending: 0 },
    jp_companies: { total: 0, folders_created: 0, pending: 0 },
    errors: []
  };
  
  try {
    // 1. 分離美/台/日股
    const usCompanies = companyPool.filter(c => c.market === "US" || c.market === "美股");
    const twCompanies = companyPool.filter(c => c.market === "TW" || c.market === "台股");
    const jpCompanies = companyPool.filter(c => c.market === "JP" || c.market === "日股");
    
    status.us_companies.total = usCompanies.length;
    status.tw_companies.total = twCompanies.length;
    status.jp_companies.total = jpCompanies.length;
    
    // 2. 美股：自動抓取最新三季
    Logger.log(`P1 財報：開始下載 ${usCompanies.length} 檔美股財報`);
    const usReportMetadata = [];
    for (const company of usCompanies) {
      try {
        const result = fetchSECFinancialReport(company.ticker);
        if (result && result.quarterly_reports && result.quarterly_reports.length > 0) {
          status.us_companies.success++;
          usReportMetadata.push({
            ticker: company.ticker,
            company_name: company.company_name,
            market: "US",
            reports: result.quarterly_reports
          });
        } else {
          status.us_companies.failed++;
          status.errors.push(`${company.ticker} (US): 抓取失敗`);
          markFinancialReportStatus(company.ticker, "US", "FAILED", jobId);
        }
      } catch (error) {
        status.us_companies.failed++;
        status.errors.push(`${company.ticker} (US): ${error.message}`);
        markFinancialReportStatus(company.ticker, "US", "FAILED", jobId);
      }
    }
    
    // 3. 美股：立即進行 Flash 提取（HTML 內容直接提取）
    if (usReportMetadata.length > 0) {
      Logger.log(`P1 財報：開始提取 ${usReportMetadata.length} 檔美股財報（Flash 三欄位）`);
      for (const metadata of usReportMetadata) {
        try {
          const extractionResults = [];
          for (const report of metadata.reports) {
            const filingPeriod = `${report.filing_date.substring(0, 4)}-Q${getQuarterFromDate(report.filing_date)}`;
            const extracted = extractFinancialReportSegments(
              report.html_content,  // HTML 內容直接傳入
              metadata.ticker,
              metadata.market,
              filingPeriod,
              "HTML"
            );
            if (extracted) {
              extractionResults.push({
                filing_period: filingPeriod,
                filing_type: report.filing_type,
                filing_date: report.filing_date,
                extracted_data: extracted
              });
            }
          }
          
          // 合併三季提取結果（選項 B：合併存儲）
          const mergedExtraction = mergeQuarterlyExtractions(extractionResults);
          
          // 保存到表格
          saveFinancialReportExtraction(metadata.ticker, metadata.market, mergedExtraction, jobId);
          
        } catch (error) {
          Logger.log(`P1 財報：提取 ${metadata.ticker} 失敗：${error.message}`);
          status.errors.push(`${metadata.ticker} (US): 提取失敗 - ${error.message}`);
        }
      }
    }
    
    // 4. 台股/日股：創建 Google Drive 子資料夾
    if (twCompanies.length > 0) {
      Logger.log(`P1 財報：為 ${twCompanies.length} 檔台股創建 Google Drive 資料夾`);
      const folderResults = createFinancialReportFolders(twCompanies, "TW", jobId);
      status.tw_companies.folders_created = folderResults.created;
      status.tw_companies.pending = folderResults.pending;
    }
    
    if (jpCompanies.length > 0) {
      Logger.log(`P1 財報：為 ${jpCompanies.length} 檔日股創建 Google Drive 資料夾`);
      const folderResults = createFinancialReportFolders(jpCompanies, "JP", jobId);
      status.jp_companies.folders_created = folderResults.created;
      status.jp_companies.pending = folderResults.pending;
    }
    
    Logger.log(`P1 財報下載階段完成：美股 ${status.us_companies.success}/${status.us_companies.total} 成功`);
    
    return status;
    
  } catch (error) {
    Logger.log(`P1 財報下載階段失敗：${error.message}`);
    status.errors.push(`整體錯誤：${error.message}`);
    return status;
  }
}

/**
 * 創建 Google Drive 子資料夾（台股/日股）
 * @param {Array} companies - 公司清單
 * @param {string} market - 市場（TW/JP）
 * @param {string} jobId - Job ID
 * @return {Object} 創建結果
 */
function createFinancialReportFolders(companies, market, jobId) {
  const result = { created: 0, pending: 0, errors: [] };
  
  try {
    // 獲取母資料夾 ID（從配置或 PropertiesService）
    const parentFolderId = getFinancialReportParentFolderId();
    if (!parentFolderId) {
      throw new Error("未配置 Google Drive 母資料夾 ID");
    }
    
    const parentFolder = DriveApp.getFolderById(parentFolderId);
    const marketFolderName = market === "TW" ? "台股" : "日股";
    
    // 創建市場資料夾（如果不存在）
    let marketFolder;
    const existingFolders = parentFolder.getFoldersByName(marketFolderName);
    if (existingFolders.hasNext()) {
      marketFolder = existingFolders.next();
    } else {
      marketFolder = parentFolder.createFolder(marketFolderName);
    }
    
    // 為每個公司創建子資料夾
    for (const company of companies) {
      try {
        const folderName = `${company.ticker}_${company.company_name}`;
        const existingCompanyFolders = marketFolder.getFoldersByName(folderName);
        
        if (!existingCompanyFolders.hasNext()) {
          const companyFolder = marketFolder.createFolder(folderName);
          result.created++;
          
          // 保存資料夾資訊
          saveFinancialReportFolderInfo(company.ticker, market, companyFolder.getId(), jobId);
        } else {
          // 資料夾已存在，檢查是否有 PDF
          const companyFolder = existingCompanyFolders.next();
          const pdfFiles = companyFolder.getFilesByType(MimeType.PDF);
          if (!pdfFiles.hasNext()) {
            result.pending++;
            saveFinancialReportFolderInfo(company.ticker, market, companyFolder.getId(), jobId);
          }
        }
      } catch (error) {
        result.errors.push(`${company.ticker}: ${error.message}`);
      }
    }
    
    Logger.log(`P1 財報：${marketFolderName} 創建 ${result.created} 個資料夾，${result.pending} 個待處理`);
    return result;
    
  } catch (error) {
    Logger.log(`P1 財報：創建 ${market} 資料夾失敗：${error.message}`);
    result.errors.push(error.message);
    return result;
  }
}

/**
 * 獲取 Google Drive 母資料夾 ID（從 PropertiesService 或配置）
 * @return {string|null} 母資料夾 ID
 */
function getFinancialReportParentFolderId() {
  // 優先從 PropertiesService 讀取
  const properties = PropertiesService.getScriptProperties();
  let folderId = properties.getProperty("FINANCIAL_REPORT_PARENT_FOLDER_ID");
  
  if (!folderId) {
    // 如果沒有配置，返回 null（需要人工配置）
    Logger.log("警告：未配置 FINANCIAL_REPORT_PARENT_FOLDER_ID，請在 PropertiesService 中設置");
  }
  
  return folderId;
}

/**
 * 保存財報資料夾資訊
 * @param {string} ticker - 股票代號
 * @param {string} market - 市場
 * @param {string} folderId - Google Drive 資料夾 ID
 * @param {string} jobId - Job ID
 */
function saveFinancialReportFolderInfo(ticker, market, folderId, jobId) {
  // 保存到 PropertiesService 或臨時表格
  const properties = PropertiesService.getScriptProperties();
  const key = `P1_FOLDER_${ticker}_${market}_${jobId}`;
  properties.setProperty(key, folderId);
  Logger.log(`P1 財報：保存 ${ticker} (${market}) 資料夾資訊：${folderId}`);
}

/**
 * 掃描 Google Drive 子資料夾中的 PDF 並提取
 * @param {string} jobId - Job ID
 * @return {Object} 掃描結果
 */
function P1_ScanAndExtractDrivePDFs(jobId) {
  const result = {
    scanned: 0,
    extracted: 0,
    failed: 0,
    errors: []
  };
  
  try {
    // 1. 從 PropertiesService 讀取所有資料夾資訊
    const properties = PropertiesService.getScriptProperties();
    const allKeys = properties.getKeys();
    const folderKeys = allKeys.filter(key => key.startsWith(`P1_FOLDER_`) && key.endsWith(`_${jobId}`));
    
    Logger.log(`P1 財報：找到 ${folderKeys.length} 個資料夾需要掃描`);
    
    for (const key of folderKeys) {
      try {
        const folderId = properties.getProperty(key);
        if (!folderId) continue;
        
        // 解析 ticker 和 market
        const parts = key.replace(`P1_FOLDER_`, '').replace(`_${jobId}`, '').split('_');
        const market = parts.pop();
        const ticker = parts.join('_');
        
        // 掃描資料夾中的 PDF
        const folder = DriveApp.getFolderById(folderId);
        const pdfFiles = folder.getFilesByType(MimeType.PDF);
        
        if (!pdfFiles.hasNext()) {
          Logger.log(`P1 財報：${ticker} (${market}) 資料夾中沒有 PDF`);
          continue;
        }
        
        result.scanned++;
        
        // 處理每個 PDF
        const pdfList = [];
        while (pdfFiles.hasNext()) {
          pdfList.push(pdfFiles.next());
        }
        
        // 批次處理 PDF（最多處理最新三季）
        const sortedPDFs = pdfList.sort((a, b) => b.getDateCreated().getTime() - a.getDateCreated().getTime());
        const latestThreePDFs = sortedPDFs.slice(0, 3);
        
        const extractionResults = [];
        for (const pdfFile of latestThreePDFs) {
          try {
            // 上傳到 Gemini File API
            const pdfBlob = pdfFile.getBlob();
            const fileUri = uploadFileToGemini(pdfBlob, pdfFile.getName());
            
            // 推斷財報期間（從檔名或日期）
            const filingPeriod = inferFilingPeriodFromFileName(pdfFile.getName(), pdfFile.getDateCreated());
            
            // Flash 提取
            const extracted = extractFinancialReportSegments(
              fileUri,
              ticker,
              market,
              filingPeriod,
              "PDF"
            );
            
            if (extracted) {
              extractionResults.push({
                filing_period: filingPeriod,
                filing_type: "PDF",
                filing_date: pdfFile.getDateCreated().toISOString().split('T')[0],
                extracted_data: extracted
              });
            }
            
            // 刪除 Gemini 檔案（使用全局函數，如果不存在則使用本地版本）
            if (typeof deleteGeminiFile === 'function') {
              deleteGeminiFile(fileUri);
            } else {
              deleteGeminiFile_P1(fileUri);
            }
            
          } catch (error) {
            Logger.log(`P1 財報：處理 ${ticker} (${market}) PDF ${pdfFile.getName()} 失敗：${error.message}`);
            result.errors.push(`${ticker} (${market}): ${pdfFile.getName()} - ${error.message}`);
          }
        }
        
        if (extractionResults.length > 0) {
          // 合併三季提取結果
          const mergedExtraction = mergeQuarterlyExtractions(extractionResults);
          
          // 保存到表格
          saveFinancialReportExtraction(ticker, market, mergedExtraction, jobId);
          result.extracted++;
        }
        
      } catch (error) {
        result.failed++;
        result.errors.push(`處理資料夾 ${key} 失敗：${error.message}`);
      }
    }
    
    Logger.log(`P1 財報掃描完成：掃描 ${result.scanned} 個，提取 ${result.extracted} 個，失敗 ${result.failed} 個`);
    return result;
    
  } catch (error) {
    Logger.log(`P1 財報掃描失敗：${error.message}`);
    result.errors.push(`整體錯誤：${error.message}`);
    return result;
  }
}

/**
 * 從檔名推斷財報期間
 * @param {string} fileName - 檔名
 * @param {Date} fileDate - 檔案日期
 * @return {string} 財報期間（例如：2025-Q1）
 */
function inferFilingPeriodFromFileName(fileName, fileDate) {
  // 嘗試從檔名提取年份和季度
  const yearMatch = fileName.match(/(20\d{2})/);
  const quarterMatch = fileName.match(/[Qq]?([1-4])/);
  
  if (yearMatch && quarterMatch) {
    return `${yearMatch[1]}-Q${quarterMatch[1]}`;
  }
  
  // 如果無法從檔名推斷，使用檔案日期
  const year = fileDate.getFullYear();
  const month = fileDate.getMonth() + 1;
  let quarter = 1;
  if (month >= 1 && month <= 3) quarter = 1;
  else if (month >= 4 && month <= 6) quarter = 2;
  else if (month >= 7 && month <= 9) quarter = 3;
  else quarter = 4;
  
  return `${year}-Q${quarter}`;
}

/**
 * 刪除 Gemini File API 檔案
 * @param {string} fileUri - Gemini File API URI
 * 
 * ⚠️ 注意：如果 09_P0_VALIDATION.js 中已有此函數，此處為重複定義（GAS 全局作用域會覆蓋）
 * 建議統一使用 09_P0_VALIDATION.js 中的版本
 */
function deleteGeminiFile_P1(fileUri) {
  try {
    const apiKey = getAPIKey("GOOGLE");
    const fileId = fileUri.replace("files/", "");
    const deleteUrl = `https://generativelanguage.googleapis.com/v1beta/files/${fileId}?key=${apiKey}`;
    
    const response = UrlFetchApp.fetch(deleteUrl, {
      method: "DELETE",
      headers: {
        "x-goog-api-key": apiKey
      },
      muteHttpExceptions: true
    });
    
    if (response.getResponseCode() === 200) {
      Logger.log(`P1 財報：已刪除 Gemini 檔案 ${fileId}`);
    } else {
      Logger.log(`P1 財報：刪除 Gemini 檔案失敗：${response.getContentText()}`);
    }
  } catch (error) {
    Logger.log(`P1 財報：刪除 Gemini 檔案時發生錯誤：${error.message}`);
  }
}

/**
 * 保存財報元數據
 * @param {string} ticker - 股票代號
 * @param {string} market - 市場
 * @param {Object} reportData - 財報數據
 * @param {string} jobId - Job ID
 */
function saveFinancialReportMetadata(ticker, market, reportData, jobId) {
  // 保存到 Financial_Reports_Metadata 表格
  Logger.log(`P1 財報：保存 ${ticker} (${market}) 財報元數據`);
}

/**
 * 標記財報狀態
 * @param {string} ticker - 股票代號
 * @param {string} market - 市場
 * @param {string} status - 狀態（FAILED/PENDING/EXTRACTED）
 * @param {string} jobId - Job ID
 */
function markFinancialReportStatus(ticker, market, status, jobId) {
  Logger.log(`P1 財報：標記 ${ticker} (${market}) 狀態為 ${status}`);
}

/**
 * 從日期獲取季度
 * @param {string} dateString - 日期字串（YYYY-MM-DD）
 * @return {number} 季度（1-4）
 */
function getQuarterFromDate(dateString) {
  const date = new Date(dateString);
  const month = date.getMonth() + 1;  // 1-12
  if (month >= 1 && month <= 3) return 1;
  if (month >= 4 && month <= 6) return 2;
  if (month >= 7 && month <= 9) return 3;
  return 4;
}

/**
 * 合併三季提取結果（選項 B：合併存儲）
 * @param {Array} extractionResults - 各季提取結果
 * @return {Object} 合併後的提取結果
 */
function mergeQuarterlyExtractions(extractionResults) {
  const merged = {
    p1_industry_evidence: [],
    p2_financial_evidence: [],
    p3_technical_evidence: []
  };
  
  for (const result of extractionResults) {
    const extracted = result.extracted_data;
    if (extracted) {
      // 合併 P1 證據（標註季度）
      if (extracted.p1_industry_evidence) {
        for (const evidence of extracted.p1_industry_evidence) {
          merged.p1_industry_evidence.push({
            ...evidence,
            filing_period: result.filing_period,
            filing_type: result.filing_type,
            filing_date: result.filing_date
          });
        }
      }
      
      // 合併 P2 證據（標註季度）
      if (extracted.p2_financial_evidence) {
        for (const evidence of extracted.p2_financial_evidence) {
          merged.p2_financial_evidence.push({
            ...evidence,
            filing_period: result.filing_period,
            filing_type: result.filing_type,
            filing_date: result.filing_date
          });
        }
      }
      
      // 合併 P3 證據（標註季度）
      if (extracted.p3_technical_evidence) {
        for (const evidence of extracted.p3_technical_evidence) {
          merged.p3_technical_evidence.push({
            ...evidence,
            filing_period: result.filing_period,
            filing_type: result.filing_type,
            filing_date: result.filing_date
          });
        }
      }
    }
  }
  
  return merged;
}

/**
 * 保存財報提取結果到表格
 * @param {string} ticker - 股票代號
 * @param {string} market - 市場
 * @param {Object} extractedData - 提取結果
 * @param {string} jobId - Job ID
 */
function saveFinancialReportExtraction(ticker, market, extractedData, jobId) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName("Phase1_Company_Pool");
    
    if (!sheet) {
      Logger.log(`P1 財報：Phase1_Company_Pool 表格不存在，無法保存提取結果`);
      return;
    }
    
    // 查找該公司的記錄
    const dataRange = sheet.getDataRange();
    const rows = dataRange.getValues();
    const headers = rows[0];
    const tickerCol = headers.indexOf("Company_Code");
    const marketCol = headers.indexOf("Market");
    
    if (tickerCol === -1 || marketCol === -1) {
      Logger.log(`P1 財報：找不到 Company_Code 或 Market 欄位`);
      return;
    }
    
    // 查找對應的公司記錄
    for (let i = 1; i < rows.length; i++) {
      if (rows[i][tickerCol] === ticker && rows[i][marketCol] === market) {
        // 找到記錄，更新三個 JSON 欄位
        const p1Col = headers.indexOf("P1_Industry_Evidence_JSON");
        const p2Col = headers.indexOf("P2_Financial_Evidence_JSON");
        const p3Col = headers.indexOf("P3_Technical_Evidence_JSON");
        const statusCol = headers.indexOf("Financial_Report_Extraction_Status");
        
        if (p1Col !== -1) {
          sheet.getRange(i + 1, p1Col + 1).setValue(JSON.stringify(extractedData.p1_industry_evidence || []));
        }
        if (p2Col !== -1) {
          sheet.getRange(i + 1, p2Col + 1).setValue(JSON.stringify(extractedData.p2_financial_evidence || []));
        }
        if (p3Col !== -1) {
          sheet.getRange(i + 1, p3Col + 1).setValue(JSON.stringify(extractedData.p3_technical_evidence || []));
        }
        if (statusCol !== -1) {
          sheet.getRange(i + 1, statusCol + 1).setValue("EXTRACTED");
        }
        
        Logger.log(`P1 財報：已保存 ${ticker} (${market}) 的提取結果`);
        return;
      }
    }
    
    Logger.log(`P1 財報：找不到 ${ticker} (${market}) 的記錄，無法保存提取結果`);
    
  } catch (error) {
    Logger.log(`P1 財報：保存提取結果失敗（${ticker}, ${market}）：${error.message}`);
  }
}

// ==========================================
// ⭐ V8.14 新增：Flash 三欄位提取（P1/P2/P3）
// ==========================================

/**
 * 使用 Flash 提取財報的三個欄位（P1/P2/P3）
 * @param {string} fileUri - Gemini File API URI（或 HTML 內容）
 * @param {string} ticker - 股票代號
 * @param {string} market - 市場
 * @param {string} filingPeriod - 財報期間（例如：2025-Q1）
 * @param {string} fileType - 檔案類型（PDF/HTML）
 * @return {Object|null} 提取結果 { p1_industry_evidence, p2_financial_evidence, p3_technical_evidence }
 */
function extractFinancialReportSegments(fileUri, ticker, market, filingPeriod, fileType = "PDF") {
  try {
    const apiKey = getAPIKey("GOOGLE");
    const model = "gemini-3-flash-preview";
    
    const prompt = buildFinancialReportExtractionPrompt(ticker, market, filingPeriod);
    
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
    
    // 構建請求體
    const requestBody = {
      contents: [{
        parts: [
          { text: prompt }
        ]
      }]
    };
    
    // 如果是 PDF，使用 file_data；如果是 HTML，直接放在 text 中
    if (fileType === "PDF" && fileUri.startsWith("files/")) {
      requestBody.contents[0].parts.push({
        file_data: {
          mime_type: "application/pdf",
          file_uri: fileUri
        }
      });
    } else if (fileType === "HTML") {
      // HTML 內容直接放在 prompt 後面（fileUri 實際上是 HTML 內容）
      requestBody.contents[0].parts.push({
        text: `\n\n=== 財報內容（${filingPeriod}）===\n${fileUri}`
      });
    }
    
    const response = UrlFetchApp.fetch(apiUrl, {
      method: "POST",
      headers: {
        "x-goog-api-key": apiKey,
        "Content-Type": "application/json"
      },
      payload: JSON.stringify(requestBody),
      muteHttpExceptions: true
    });
    
    if (response.getResponseCode() !== 200) {
      throw new Error(`Gemini 提取失敗：${response.getContentText()}`);
    }
    
    const result = JSON.parse(response.getContentText());
    const content = result.candidates[0].content.parts[0].text;
    
    // 解析 JSON
    let jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
    
    throw new Error("無法解析提取結果");
    
  } catch (error) {
    Logger.log(`P1 財報：提取 ${ticker} (${filingPeriod}) 失敗：${error.message}`);
    return null;
  }
}

/**
 * 構建財報提取 Prompt（三欄位分離）
 * @param {string} ticker - 股票代號
 * @param {string} market - 市場
 * @param {string} filingPeriod - 財報期間
 * @return {string} Prompt 內容
 */
function buildFinancialReportExtractionPrompt(ticker, market, filingPeriod) {
  return `
## Role Definition

You are a "Forensic Data Extractor" (法醫級數據提取員).

Your ONLY job is to read the provided financial report (PDF/Text) and extract verbatim segments for downstream analysis modules.

You possess high-speed reading capabilities and perfect memory for locating text.

---

## ⚠️ Strict Non-Functional Requirements (The Iron Rules)

1. **NO Analysis**: Do not interpret, summarize, calculate, or explain the data.
2. **NO Hallucination**: You must extract the text EXACTLY as it appears in the document. Do not change a single word.
3. **Verbatim & Context**: Extract the full sentence/paragraph containing the keyword, plus 1-2 preceding and following sentences to preserve context.
4. **Citation**: Every single extraction MUST include the specific Page Number \`(Page X)\`.
5. **Separation**: Strictly separate data into "P1_Industry_Evidence", "P2_Financial_Evidence", and "P3_Technical_Evidence".

---

## Extraction Scope

### Group 1: For P1 Analysis (Industry Position & Order of Battle)

Target: Information regarding "Who they are," "Where they fit in the supply chain," and "Strategic MOAT."

Look for paragraphs containing:

- **Business Description**: What does the company do? Main products/services?
- **Revenue Mix (Sales Breakdown)**: Revenue by product category or geography (e.g., "Mobile accounts for 50%...").
- **Supply Chain Role**: Mentions of "suppliers," "customers," "clients," "distributors," or "manufacturing process."
- **Competition**: Mentions of "competitors," "market share," "industry position," "rivals."
- **R&D & Technology**: Mentions of "patents," "technology barriers," "R&D expenses" (as a strategic effort), "new product launch."
- **Capacity**: Mentions of "factories," "production lines," "utilization rate," "expansion plans."

### Group 2: For P2 Analysis (Financial Safety & Growth)

Target: Information regarding "Financial Health," "Valuation," and "Growth Trends."

Look for paragraphs and tables containing:

- **Profitability**: Gross Margin, Operating Margin, Net Profit, EPS.
- **Growth**: Revenue growth rates, YoY comparisons, QoQ comparisons.
- **Balance Sheet Health**: Cash on hand, Total Debt, Inventory levels, Inventory Turnover days, Liabilities.
- **Cash Flow**: Operating Cash Flow, Free Cash Flow, Capital Expenditure (CapEx), Dividends.
- **Guidance & Outlook**: Management's prediction for the next quarter/year, order visibility, backlog.
- **Risk Factors**: Specific financial risks mentioned in the "Risk Factors" section.

**Important**: If a section implies a table, convert it to a Markdown table format within the "content" field.

### Group 3: For P3 Analysis (Technical Sentiment & Chips)

Target: Information regarding "Shareholder Structure," "Potential Selling Pressure," and "Insider Confidence."

Look for paragraphs and tables containing:

- **Shareholding Structure**: Major shareholders list, Director/Management shareholding percentage changes.
- **Potential Dilution**: Mentions of "Convertible Bonds (CB)" (especially conversion price and period), "Employee Stock Options," "Preferred Stock."
- **Capital Actions**: Mentions of "Share Repurchase (Buyback)," "Capital Reduction," "Private Placement" (私募).
- **Dividends Policy**: Cash dividend proposals (affects technical yield support).

---

## Output Format (Strict JSON)

Output a single JSON object with three main arrays. Each extraction must include:

\`\`\`json
{
  "p1_industry_evidence": [
    {
      "content": "完整的原文段落（直接從文件中複製，不要改寫）",
      "page_number": 15,
      "section": "Business Description / 業務描述 / 公司概況",
      "filing_period": "${filingPeriod}",
      "context_before": "前文（如果需要理解該段落，必須包含的前文）",
      "context_after": "後文（如果需要理解該段落，必須包含的後文）"
    }
  ],
  "p2_financial_evidence": [
    {
      "content": "完整的原文段落或 Markdown 表格（直接從文件中複製）",
      "page_number": 23,
      "section": "Financial Statements / 財務報表 / 損益表",
      "filing_period": "${filingPeriod}",
      "table_format": "如果內容是表格，轉換為 Markdown 格式",
      "context_before": "前文",
      "context_after": "後文"
    }
  ],
  "p3_technical_evidence": [
    {
      "content": "完整的原文段落（直接從文件中複製）",
      "page_number": 45,
      "section": "Shareholding Structure / 股權結構",
      "filing_period": "${filingPeriod}",
      "context_before": "前文",
      "context_after": "後文"
    }
  ]
}
\`\`\`

---

## ⚠️ Critical Instructions

1. **Extraction Order**: First locate section titles, then extract content.
2. **Table Handling**: Financial tables must be converted to Markdown format within the "content" field.
3. **Multi-language Support**: For TW/JP market reports, handle Chinese/Japanese text correctly.
4. **Context Preservation**: Each paragraph must include 1-2 preceding and following sentences.
5. **Page Numbers**: Every extraction MUST include the exact page number.
6. **No Calculation**: Do not calculate any metrics (e.g., growth rates, margins). Only extract raw data.

---

## Company Information

- **Ticker**: ${ticker}
- **Market**: ${market}
- **Filing Period**: ${filingPeriod}

**Now extract the data according to the above rules.**
`;
}
