/**
 * 📊 P5 Weekly: 最終產出格式模組
 * ⭐ V8.15 新增
 * 
 * 實現 P5 Weekly 最終產出格式（對齊 IB 批次下單）：
 * - weekly_trade_actions：包含所有股票的掛單動作
 * - cancel_previous_orders：取消上週掛單
 * - new_orders：新掛單列表
 * - strategy_version：策略版本標記
 * 
 * @version SSOT V8.15
 * @date 2026-01-19
 */

/**
 * 生成 P5 Weekly 最終產出（對齊 IB 批次下單）
 * ⭐ V8.15 新增：整合 Strategy Skeleton 和 Parameter Adjustment Vector
 * 
 * @param {Object} stockStrategies - 所有股票的策略結果（來自 P5-B/P5-A）
 * @param {Object} context - 上下文數據
 * @returns {Object} weekly_trade_actions - 最終產出格式
 */
function generateWeeklyTradeActions(stockStrategies, context) {
  try {
    const now = new Date();
    const year = now.getFullYear();
    const weekNumber = getWeekNumber(now);
    const strategyVersion = `W${year}-${weekNumber.toString().padStart(2, '0')}`;
    
    const weeklyTradeActions = {
      generated_at: now.toISOString(),
      strategy_version: strategyVersion,
      weekly_trade_actions: []
    };
    
    // 處理每檔股票
    for (const ticker in stockStrategies) {
      const strategy = stockStrategies[ticker];
      
      // 獲取 Strategy Skeleton 和 Parameter Adjustment Vector
      const strategySkeleton = strategy.strategy_skeleton || null;
      const parameterAdjustmentVector = strategy.parameter_adjustment_vector || 
                                        strategy.p5_b_result?.parameter_adjustment_vector || null;
      
      // 獲取當前價格和 ATR
      const currentPrice = context.current_positions?.[ticker]?.current_price || 
                          context.dailyData?.ohlcv?.[ticker]?.close || null;
      const atr = context.dailyData?.technical_indicators?.[ticker]?.atr || null;
      
      // 生成最終掛單
      let finalOrders = null;
      if (strategySkeleton && parameterAdjustmentVector && currentPrice && atr) {
        try {
          finalOrders = applyParameterAdjustmentVector(
            strategySkeleton,
            parameterAdjustmentVector,
            currentPrice,
            atr
          );
        } catch (error) {
          Logger.log(`P5 Weekly：應用 Parameter Adjustment Vector 失敗（${ticker}）：${error.message}`);
        }
      }
      
      // 獲取上週掛單（用於取消）
      const previousOrders = context.open_orders?.[ticker] || [];
      
      // 構建該股票的 trade action
      const tradeAction = {
        ticker: ticker,
        cancel_previous_orders: previousOrders.length > 0,
        previous_orders: previousOrders.map(order => ({
          order_id: order.order_id || order.id,
          type: order.type || order.side,
          price: order.price,
          qty: order.qty || order.quantity
        })),
        new_orders: finalOrders ? [
          ...finalOrders.buy_orders.map(order => ({
            type: "BUY",
            price: order.price,
            qty: order.qty || null,  // 數量由 P4 決定
            order_id: order.id,
            formula: order.formula
          })),
          ...finalOrders.sell_orders.map(order => ({
            type: "SELL",
            price: order.price,
            qty: order.qty || null,  // 數量由 P4 決定
            order_id: order.id,
            formula: order.formula,
            is_trailing: order.is_trailing || false
          }))
        ] : [],
        strategy_version: strategyVersion,
        evaluation_layer: strategy.evaluation_layer || "P5_B",
        escalation_reason: strategy.escalation_reason || [],
        risk_frame: finalOrders?.risk_frame || null,
        reasoning: strategy.reasoning || strategy.p5_b_result?.reasoning || null
      };
      
      weeklyTradeActions.weekly_trade_actions.push(tradeAction);
    }
    
    Logger.log(`P5 Weekly：生成最終產出 - 共 ${weeklyTradeActions.weekly_trade_actions.length} 檔股票`);
    
    return weeklyTradeActions;
    
  } catch (error) {
    Logger.log(`P5 Weekly：生成最終產出失敗：${error.message}`);
    throw error;
  }
}

/**
 * 獲取週數（輔助函數）
 * 
 * @param {Date} date - 日期
 * @return {number} 週數
 */
function getWeekNumber(date) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
}
