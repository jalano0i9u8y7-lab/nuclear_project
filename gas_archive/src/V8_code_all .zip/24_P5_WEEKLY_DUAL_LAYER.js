/**
 * 📊 P5 Weekly: 雙層 AI 架構模組 ⭐ V8.15 新增
 * 
 * 實現 P5-B（低成本評估器）和 P5-A（深度重評估）雙層架構
 * - P5-B：每檔都跑（低成本，Claude Sonnet 4.5）
 * - P5-A：僅升級少數（10-20%，Claude Sonnet 4.5 或 Opus）
 * - Escalation Gate：決定是否觸發 P5-A
 * 
 * @version SSOT V8.15
 * @date 2026-01-19
 * 
 * ⭐ V8.15 依賴：
 * - 24_P5_WEEKLY_STRATEGY_SKELETON.js（Strategy Skeleton 與 Parameter Adjustment Vector）
 * - 24_P5_WEEKLY_STOCK_STRATEGY.js（integrateStockFactors、extractP2_5StockData）
 */

// ==========================================
// P5-B（Weekly State Evaluator）配置
// ==========================================

const P5_B_CONFIG = {
  MODEL: "CLAUDE_SONNET_4_5",
  BATCH_SIZE: 10,  // P5-B 可以批次更大（低成本）
  BATCH_DELAY_MS: 1000
};

// ==========================================
// P5-A（Weekly Deep Re-evaluation）配置
// ==========================================

const P5_A_CONFIG = {
  MODEL: "OPUS",  // ⭐ V8.17 更新：Batch 版本一律使用 Opus（因為已經只處理 20%+ Batch，沒必要妥協用便宜的模型）
  BATCH_SIZE: 3,  // P5-A 批次較小（深度分析）
  BATCH_DELAY_MS: 2000
};

// ==========================================
// Escalation Gate 配置
// ==========================================

const ESCALATION_GATE_CONFIG = {
  // 軟觸發條件（基於 escalation_score）
  ESCALATION_SCORE_THRESHOLD: 0.6,
  TREND_INTEGRITY_THRESHOLD: 0.4,
  DISTRIBUTION_RISK_THRESHOLD: 0.7,
  
  // 硬觸發條件（P2.5 異常）
  P2_5_INSIDER_SELLING_ALERT: true,  // 直接觸發
  P2_5_ABNORMAL_13F_DISTRIBUTION: true,  // 直接觸發
  
  // Chain Dynamics 觸發
  CHAIN_DYNAMICS_DIVERGENCE: "DIVERGENCE"
};

/**
 * 計算 Escalation Score（決定是否觸發 P5-A）
 * ⭐ V8.15 新增：整合 P2.5 異常硬觸發
 * 
 * @param {Object} stockData - 股票數據（已整合所有因子）
 * @returns {Object} escalationResult - 升級結果
 */
function calculateEscalationScore(stockData) {
  try {
    let escalationScore = 0.0;
    const reasons = [];
    let forcedEscalation = false;
    
    // ⭐ V8.15 硬觸發條件 1：P2.5 異常警報
    if (stockData.p2_5_data) {
      if (stockData.p2_5_data.insider_selling_alert === true) {
        escalationScore = 1.0;  // 強制升級
        forcedEscalation = true;
        reasons.push({
          type: "P2_5_INSIDER_SELLING",
          severity: "HIGH",
          message: "內部人大量賣出，強制深度重評估"
        });
      } else if (stockData.p2_5_data.abnormal_13f_distribution === true) {
        escalationScore = 1.0;  // 強制升級
        forcedEscalation = true;
        reasons.push({
          type: "P2_5_ABNORMAL_13F",
          severity: "HIGH",
          message: "13F 異常分布，強制深度重評估"
        });
      }
    }
    
    // 如果已硬觸發，直接返回
    if (forcedEscalation) {
      return {
        escalation_score: escalationScore,
        should_escalate: true,
        forced_escalation: {
          trigger: "P2.5",
          type: reasons[0].type,
          confidence: "HIGH",
          note: reasons[0].message
        },
        reasons: reasons
      };
    }
    
    // 軟觸發條件（基於 state_vector）
    const stateVector = stockData.state_vector || {};
    
    // 1. Trend Integrity 檢查
    if (stateVector.trend_integrity !== undefined) {
      if (stateVector.trend_integrity < ESCALATION_GATE_CONFIG.TREND_INTEGRITY_THRESHOLD) {
        escalationScore += 0.3;
        reasons.push({
          type: "LOW_TREND_INTEGRITY",
          severity: "MEDIUM",
          message: `趨勢完整性低（${stateVector.trend_integrity.toFixed(2)}）`
        });
      }
    }
    
    // 2. Distribution Risk 檢查
    if (stateVector.distribution_risk !== undefined) {
      if (stateVector.distribution_risk > ESCALATION_GATE_CONFIG.DISTRIBUTION_RISK_THRESHOLD) {
        escalationScore += 0.3;
        reasons.push({
          type: "HIGH_DISTRIBUTION_RISK",
          severity: "MEDIUM",
          message: `派發風險高（${stateVector.distribution_risk.toFixed(2)}）`
        });
      }
    }
    
    // 3. Chain Dynamics Divergence 檢查
    if (stockData.p0_5_data && stockData.p0_5_data.chain_monitor) {
      const chainState = stockData.p0_5_data.chain_monitor.diagnosis?.current_chain_state;
      if (chainState === ESCALATION_GATE_CONFIG.CHAIN_DYNAMICS_DIVERGENCE) {
        escalationScore += 0.2;
        reasons.push({
          type: "CHAIN_DYNAMICS_DIVERGENCE",
          severity: "MEDIUM",
          message: "產業鏈出現背離訊號"
        });
      }
    }
    
    // 4. P6 頻率趨勢檢查
    if (stockData.p6_frequency_trend === "SURGE") {
      escalationScore += 0.2;
      reasons.push({
        type: "P6_FREQUENCY_SURGE",
        severity: "MEDIUM",
        message: "盤中異常頻率暴增"
      });
    }
    
    // 5. Milestone Check（P2 Milestones 自動對帳）⭐ V8.15 增強
    if (stockData.p2_v8_15_fields && stockData.p2_v8_15_fields.milestones_to_verify_json) {
      const milestones = stockData.p2_v8_15_fields.milestones_to_verify_json;
      if (Array.isArray(milestones) && milestones.length > 0) {
        // ⭐ V8.15：執行完整的 Milestone Check
        const milestoneCheckResult = performMilestoneCheck(
          stockData.ticker,
          milestones,
          stockData.stock_news_index || {}
        );
        
        // 如果有里程碑達成，增加 escalation_score
        if (milestoneCheckResult.matched && milestoneCheckResult.matched.length > 0) {
          escalationScore += 0.2;  // 里程碑達成是重要事件
          reasons.push({
            type: "MILESTONE_MET",
            severity: "MEDIUM",
            message: `有 ${milestoneCheckResult.matched.length} 個里程碑已達成`,
            matched_milestones: milestoneCheckResult.matched.map(m => m.milestone.description || m.milestone.milestone)
          });
        }
        
        // 如果有里程碑錯過，增加 escalation_score
        if (milestoneCheckResult.missed && milestoneCheckResult.missed.length > 0) {
          escalationScore += 0.15;
          reasons.push({
            type: "MILESTONE_MISSED",
            severity: "MEDIUM",
            message: `有 ${milestoneCheckResult.missed.length} 個里程碑已錯過`,
            missed_milestones: milestoneCheckResult.missed.map(m => m.milestone.description || m.milestone.milestone)
          });
        }
        
        // 如果有里程碑接近達成時間，輕微增加 escalation_score
        const nearMilestones = milestoneCheckResult.pending.filter(m => {
          return m.days_until <= 30;  // 30 天內
        });
        if (nearMilestones.length > 0) {
          escalationScore += 0.1;
          reasons.push({
            type: "MILESTONE_NEAR",
            severity: "LOW",
            message: `有 ${nearMilestones.length} 個里程碑接近達成時間`
          });
        }
        
        // 將 Milestone Check 結果附加到 stockData
        stockData.milestone_check_result = milestoneCheckResult;
      }
    }
    
    // 判斷是否觸發 P5-A
    const shouldEscalate = escalationScore >= ESCALATION_GATE_CONFIG.ESCALATION_SCORE_THRESHOLD;
    
    return {
      escalation_score: Math.min(1.0, escalationScore),
      should_escalate: shouldEscalate,
      forced_escalation: null,
      reasons: reasons
    };
    
  } catch (error) {
    Logger.log(`計算 Escalation Score 失敗（${stockData.ticker}）：${error.message}`);
    return {
      escalation_score: 0.0,
      should_escalate: false,
      forced_escalation: null,
      reasons: []
    };
  }
}

/**
 * P5-B（Weekly State Evaluator）
 * 每檔都跑（低成本，Claude Sonnet 4.5）
 * 
 * @param {Array} tickers - 股票列表
 * @param {Object} context - 上下文數據
 * @returns {Object} p5BResults - P5-B 結果
 */
function P5_B_Execute(tickers, context) {
  try {
    Logger.log(`P5-B 執行開始：共 ${tickers.length} 檔股票`);
    
    // ⭐ V8.17 新增：判斷是否使用 Batch API
    const useBatch = shouldUseBatch("P5_B_WEEKLY_STATE_EVALUATOR");
    const executorModel = TASK_TO_EXECUTOR["P5_B_WEEKLY_STATE_EVALUATOR"] || "SONNET";
    const executorConfig = M0_MODEL_CONFIG[executorModel];
    const canUseBatch = useBatch && executorConfig && executorConfig.supportsBatch;
    
    if (canUseBatch) {
      Logger.log(`P5-B：使用 Batch API（Provider: ${executorConfig.adapter === "M0_Adapter_Claude" ? "anthropic" : "openai"}, Model: ${executorConfig.model}）`);
      
      // ⭐ V8.17 新增：使用 Batch API 處理所有股票
      return P5_B_ExecuteWithBatch(tickers, context);
    } else {
      Logger.log(`P5-B：使用同步 API（不適用 Batch 或模型不支援）`);
      
      // ⭐ V8.16 保留：同步 API 處理（作為備用）
      return P5_B_ExecuteWithSyncAPI(tickers, context);
    }
    
  } catch (error) {
    Logger.log(`P5-B 執行失敗：${error.message}`);
    throw error;
  }
}

/**
 * ⭐ V8.17 新增：P5-B 使用 Batch API 執行
 */
function P5_B_ExecuteWithBatch(tickers, context) {
  try {
    Logger.log(`P5-B：開始 Batch API 處理（共 ${tickers.length} 檔股票）`);
    
    // 為每檔股票整合因子數據
    const allStockData = [];
    for (const ticker of tickers) {
      const stockData = integrateStockFactors(ticker, context);
      
      // ⭐ V8.15 新增：生成 Strategy Skeleton
      const strategySkeleton = generateStrategySkeleton(
        ticker,
        stockData.p3_data,
        stockData.p4_data,
        {
          close: stockData.daily_ohlcv?.close || null,
          atr: stockData.daily_technical?.atr || null,
          ohlcv: stockData.daily_ohlcv,
          technical_indicators: stockData.daily_technical
        }
      );
      stockData.strategy_skeleton = strategySkeleton;
      
      // ⭐ V8.15：計算 state_vector（簡化版，由 AI 輸出完整版）
      stockData.state_vector = {
        trend_integrity: calculateTrendIntegrity(stockData),
        momentum_shift: calculateMomentumShift(stockData),
        distribution_risk: calculateDistributionRisk(stockData),
        volatility_regime_change: calculateVolatilityRegimeChange(stockData)
      };
      
      // 計算 escalation_score
      const escalationResult = calculateEscalationScore(stockData);
      stockData.escalation_result = escalationResult;
      
      allStockData.push({ ticker: ticker, stockData: stockData });
    }
    
    // ⭐ V8.15 新增：確保 p6_weekly_summary 正確傳遞到 context
    const contextWithP6 = {
      ...context,
      p6_weekly_summary: context.p6_weekly_summary || context.allSnapshots?.p6_weekly_summary || null,
      p5_b_batch_items: allStockData.map(item => ({ ticker: item.ticker, stockData: item.stockData }))  // ⭐ V8.17 新增：保存 items 供後續處理使用
    };
    
    // 使用通用 Batch 執行函數
    const batchResult = executeBatchJob({
      project_id: "P5_B_WEEKLY_STATE_EVALUATOR",
      frequency: "WEEKLY",
      items: contextWithP6.p5_b_batch_items,
      buildSystemBlocks: (ctx) => buildP5_BSystemBlocks(ctx),
      buildUserPayload: (item, ctx) => buildP5_BUserPayloadForBatch(item.ticker, item.stockData, ctx),
      context: contextWithP6
    });
    
    Logger.log(`P5-B：Batch Job 已提交，batch_id=${batchResult.batch_id}`);
    
    // 返回 Batch Job ID，需要後續調用 processBatchJobResults 處理結果
    return {
      status: "SUBMITTED_BATCH",
      batch_id: batchResult.batch_id,
      provider_batch_id: batchResult.provider_batch_id,
      request_count: batchResult.request_count,
      message: `P5-B Batch Job 已提交（${batchResult.request_count} 個請求），請等待完成後執行 P5_B_ProcessBatchResults() 處理結果`
    };
    
  } catch (error) {
    Logger.log(`P5-B Batch API 處理失敗：${error.message}`);
    throw error;
  }
}

/**
 * ⭐ V8.17 新增：構建 P5-B System Blocks（可 cache 的內容）
 */
function buildP5_BSystemBlocks(context) {
  return [
    {
      type: "text",
      text: `你是 P5-B（Weekly State Evaluator）分析專家。

## 核心職責

1. **狀態評估**：評估股票當前的趨勢完整性、動量變化、分發風險、波動率制度變化
2. **參數調整**：輸出 Parameter Adjustment Vector，調整 Strategy Skeleton 的參數
3. **升級判斷**：計算 escalation_score，決定是否需要升級到 P5-A

## ⚠️ 重要：momentum_shift 判斷規則

**在判斷 momentum_shift 時，Sector ETF Flow 與 Mag7 相對強弱為高優先權因子。**

即使個股與產業鏈未出現明顯惡化，也必須考慮資金撤出造成的系統性壓力。

具體規則：
- 如果 Sector ETF Flow 顯示資金大量流出（weekly_flow_usd < -1e9 且 trend = "OUTFLOW_ACCELERATING"），必須降低 momentum_shift
- 如果 Mag7 相對強弱 vs SP500 < -2% 且 trend = "WEAKENING"，必須降低 momentum_shift
- 即使個股技術面良好，若 Sector Flow 和 Mag7 同時惡化，momentum_shift 不得 > 0.2

## 輸出格式要求

必須以 JSON 格式輸出，包含以下欄位：
- state_vector: { trend_integrity, momentum_shift, distribution_risk, volatility_regime_change }
- parameter_adjustment_vector: { buy_bias, sell_bias, ladder_spacing_adjustment, trailing_stop_tightness, max_position_cap_override }
- escalation_score: 0-1
- reasoning: 分析理由（必須說明 Sector ETF Flow 和 Mag7 對 momentum_shift 的影響）`,
      cache_control: { type: "ephemeral" }  // ⭐ 標記為可 cache
    }
  ];
}

/**
 * ⭐ V8.17 新增：構建 P5-B User Payload（動態內容）
 */
function buildP5_BUserPayloadForBatch(ticker, stockData, context) {
  // ⭐ V8.17 新增：構建 Delta Pack（變動摘要）
  const previousP5BOutput = context.previous_p5_b_results?.[ticker] || null;
  const weeklyDelta = buildDeltaPack(ticker, stockData, previousP5BOutput, context);
  
  return `## 股票資訊

Ticker: ${ticker}

## Strategy Skeleton（策略骨架）

${JSON.stringify(stockData.strategy_skeleton, null, 2)}

## 當前狀態向量（基礎計算）

${JSON.stringify(stockData.state_vector, null, 2)}

## Delta Pack（變動摘要）⭐ V8.17 新增

${JSON.stringify(weeklyDelta, null, 2)}

## 完整股票數據

${JSON.stringify(stockData, null, 2)}

## 上下文數據

${JSON.stringify({
  p0_5_snapshot: context.p0_5_snapshot || null,
  p0_7_snapshot: context.p0_7_snapshot || null,
  p2_snapshot: context.p2_snapshot || null,
  p2_5_snapshot: context.p2_5_snapshot || null,
  p3_snapshot: context.p3_snapshot || null,
  p4_snapshot: context.p4_snapshot || null,
  p6_weekly_summary: context.p6_weekly_summary || null,
  macro_flow_context: context.macro_flow_context || null
}, null, 2)}

## 你的任務

基於以上數據，進行狀態評估並輸出 JSON 格式結果。

**特別注意**：
1. **momentum_shift 判斷規則**：在判斷 momentum_shift 時，必須優先考慮 macro_flow_context 中的 sector_etf_flow 和 mag7_relative_strength。即使個股技術面良好，若 Sector Flow 和 Mag7 同時惡化，必須降低 momentum_shift（不得 > 0.2）。
2. **必須在 reasoning 中明確說明**：Sector ETF Flow 和 Mag7 對判斷的影響，以及為什麼這樣調整 momentum_shift。`;
}

/**
 * ⭐ V8.17 新增：處理 P5-B Batch 結果
 */
function P5_B_ProcessBatchResults(batchId, context) {
  try {
    Logger.log(`P5-B：開始處理 Batch 結果：${batchId}`);
    
    // 使用通用 Batch 結果處理函數
    const processResult = (executorOutput, item, ctx) => {
      const ticker = item.ticker;
      const stockData = item.stockData;
      
      // 解析執行者輸出
      let p5BResult = executorOutput;
      if (typeof p5BResult === 'string') {
        try {
          let jsonString = p5BResult.trim();
          if (jsonString.startsWith('```json')) {
            jsonString = jsonString.replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
          } else if (jsonString.startsWith('```')) {
            jsonString = jsonString.replace(/^```\s*/, '').replace(/\s*```$/, '');
          }
          p5BResult = JSON.parse(jsonString);
        } catch (e) {
          Logger.log(`P5-B：解析執行者輸出失敗（${ticker}）：${e.message}`);
          throw e;
        }
      }
      
      // ⭐ V8.16 新增：使用 Validator 驗證 P5-B 輸出
      const previousP5BOutput = ctx.previous_p5_b_results?.[ticker] || null;
      const weeklyDelta = ctx.weekly_delta?.[ticker] || null;
      
      const validationResult = validateP5_BOutput(p5BResult, previousP5BOutput, weeklyDelta);
      
      if (!validationResult.valid) {
        Logger.log(`P5-B：股票 ${ticker} Validator 驗證失敗：${validationResult.errors.join(", ")}`);
        // 回退到程式化邏輯
        const programmaticResult = generateP5_BProgrammaticResult(stockData);
        return {
          ...programmaticResult,
          validation_failed: true,
          validation_errors: validationResult.errors,
          original_ai_output: p5BResult
        };
      }
      
      // 驗證通過
      p5BResult.validation_passed = true;
      p5BResult.validation_details = validationResult.validation_details;
      
      if (validationResult.warnings.length > 0) {
        p5BResult.validation_warnings = validationResult.warnings;
      }
      
      // ⭐ V8.15 新增：應用 Parameter Adjustment Vector 到 Strategy Skeleton
      if (stockData.strategy_skeleton && p5BResult.parameter_adjustment_vector) {
        try {
          const currentPrice = stockData.daily_ohlcv?.close || null;
          const atr = stockData.daily_technical?.atr || null;
          
          if (currentPrice && atr) {
            const finalOrders = applyParameterAdjustmentVector(
              stockData.strategy_skeleton,
              p5BResult.parameter_adjustment_vector,
              currentPrice,
              atr
            );
            p5BResult.final_orders = finalOrders;
          }
        } catch (error) {
          Logger.log(`P5-B：應用 Parameter Adjustment Vector 失敗（${ticker}）：${error.message}`);
        }
      }
      
      return p5BResult;
    };
    
    // 從 Batch Job 中提取 items（需要從 context 或 Batch Job 記錄中獲取）
    // 這裡簡化處理，實際應該從 Batch Job 記錄中獲取原始 items
    const items = context.p5_b_batch_items || [];
    
    const results = processBatchJobResults(batchId, {
      project_id: "P5_B_WEEKLY_STATE_EVALUATOR",
      processResult: processResult,
      items: items,
      context: context
    });
    
    Logger.log(`P5-B：Batch 結果處理完成，成功：${results.succeeded}，失敗：${results.failed}`);
    
    return {
      status: "PROCESSED",
      batch_id: batchId,
      results: results.results,
      errors: results.errors,
      summary: {
        total: results.total_items,
        succeeded: results.succeeded,
        failed: results.failed
      }
    };
    
  } catch (error) {
    Logger.log(`P5-B Batch 結果處理失敗：${error.message}`);
    throw error;
  }
}

/**
 * ⭐ V8.16 保留：P5-B 使用同步 API 執行（作為備用）
 */
function P5_B_ExecuteWithSyncAPI(tickers, context) {
  const BATCH_SIZE = P5_B_CONFIG.BATCH_SIZE;
  const allResults = {};
  
  // 分批處理（同步 API）
  for (let i = 0; i < tickers.length; i += BATCH_SIZE) {
    const batch = tickers.slice(i, i + BATCH_SIZE);
    const batchNumber = Math.floor(i / BATCH_SIZE) + 1;
    
    Logger.log(`P5-B：處理批次 ${batchNumber} (${batch.length} 檔)`);
    
    try {
      // 為每檔股票整合因子數據
      const batchStockData = [];
      for (const ticker of batch) {
        const stockData = integrateStockFactors(ticker, context);
        
        // ⭐ V8.15 新增：生成 Strategy Skeleton
        const strategySkeleton = generateStrategySkeleton(
          ticker,
          stockData.p3_data,
          stockData.p4_data,
          {
            close: stockData.daily_ohlcv?.close || null,
            atr: stockData.daily_technical?.atr || null,
            ohlcv: stockData.daily_ohlcv,
            technical_indicators: stockData.daily_technical
          }
        );
        stockData.strategy_skeleton = strategySkeleton;
        
        // ⭐ V8.15：計算 state_vector（簡化版，由 AI 輸出完整版）
        stockData.state_vector = {
          trend_integrity: calculateTrendIntegrity(stockData),
          momentum_shift: calculateMomentumShift(stockData),
          distribution_risk: calculateDistributionRisk(stockData),
          volatility_regime_change: calculateVolatilityRegimeChange(stockData)
        };
        
        // 計算 escalation_score
        const escalationResult = calculateEscalationScore(stockData);
        stockData.escalation_result = escalationResult;
        
        batchStockData.push(stockData);
      }
      
      // ⭐ V8.15 新增：確保 p6_weekly_summary 正確傳遞到 context
      const contextWithP6 = {
        ...context,
        p6_weekly_summary: context.p6_weekly_summary || context.allSnapshots?.p6_weekly_summary || null
      };
      
      // 構建 P5-B Prompt（輕量版）
      const p5BPrompt = buildP5_BPrompt(batchStockData, contextWithP6);
      
      // 提交到 M0 Job Queue
      const jobId = submitP5ToM0JobQueue(
        "P5_B_WEEKLY_STATE_EVALUATOR",
        ["SONNET"],  // 只用 Sonnet（低成本）
        {
          batch_number: batchNumber,
          tickers: batch,
          prompt: p5BPrompt,
          context: context
        }
      );
      
      // 等待結果
      const batchResult = waitForM0JobResult(jobId);
      
      if (batchResult && batchResult.p5_b_results) {
        // 合併結果
        for (const ticker of batch) {
          if (batchResult.p5_b_results[ticker]) {
            const p5BResult = batchResult.p5_b_results[ticker];
            
            // ⭐ V8.16 新增：使用 Validator 驗證 P5-B 輸出（取代 AI 審查者）
            const stockData = batchStockData.find(s => s.ticker === ticker);
            const previousP5BOutput = context.previous_p5_b_results?.[ticker] || null;
            const weeklyDelta = context.weekly_delta?.[ticker] || null;
            
            const validationResult = validateP5_BOutput(p5BResult, previousP5BOutput, weeklyDelta);
            
            if (!validationResult.valid) {
              Logger.log(`P5-B：股票 ${ticker} Validator 驗證失敗：${validationResult.errors.join(", ")}`);
              // 如果驗證失敗，使用程式化邏輯生成結果
              p5BResult.validation_failed = true;
              p5BResult.validation_errors = validationResult.errors;
              p5BResult.validation_warnings = validationResult.warnings;
              
              // 回退到程式化邏輯
              const programmaticResult = generateP5_BProgrammaticResult(stockData);
              allResults[ticker] = {
                ...programmaticResult,
                validation_failed: true,
                validation_errors: validationResult.errors,
                original_ai_output: p5BResult
              };
              continue;
            }
            
            // 如果有警告，記錄但不阻止
            if (validationResult.warnings.length > 0) {
              Logger.log(`P5-B：股票 ${ticker} Validator 警告：${validationResult.warnings.join(", ")}`);
              p5BResult.validation_warnings = validationResult.warnings;
            }
            
            // 驗證通過，標記驗證狀態
            p5BResult.validation_passed = true;
            p5BResult.validation_details = validationResult.validation_details;
            
            // ⭐ V8.15 新增：應用 Parameter Adjustment Vector 到 Strategy Skeleton
            if (stockData.strategy_skeleton && p5BResult.parameter_adjustment_vector) {
              try {
                const currentPrice = stockData.daily_ohlcv?.close || null;
                const atr = stockData.daily_technical?.atr || null;
                
                if (currentPrice && atr) {
                  const finalOrders = applyParameterAdjustmentVector(
                    stockData.strategy_skeleton,
                    p5BResult.parameter_adjustment_vector,
                    currentPrice,
                    atr
                  );
                  p5BResult.final_orders = finalOrders;
                }
              } catch (error) {
                Logger.log(`P5-B：應用 Parameter Adjustment Vector 失敗（${ticker}）：${error.message}`);
              }
            }
            
            allResults[ticker] = p5BResult;
          }
        }
      } else {
        // 如果 AI 分析失敗，使用程式化邏輯
        Logger.log(`P5-B：批次 ${batchNumber} AI 分析失敗，使用程式化邏輯`);
        for (const ticker of batch) {
          const stockData = batchStockData.find(s => s.ticker === ticker);
          allResults[ticker] = generateP5_BProgrammaticResult(stockData);
        }
      }
      
      // 批次間延遲
      if (i + BATCH_SIZE < tickers.length) {
        Utilities.sleep(P5_B_CONFIG.BATCH_DELAY_MS);
      }
      
    } catch (error) {
      Logger.log(`P5-B：批次 ${batchNumber} 處理失敗：${error.message}`);
      for (const ticker of batch) {
        allResults[ticker] = {
          ticker: ticker,
          status: "ERROR",
          error: error.message,
          escalation_result: {
            escalation_score: 0.0,
            should_escalate: false
          }
        };
      }
    }
  }
  
  Logger.log(`P5-B 執行完成：成功 ${Object.keys(allResults).length} 檔`);
  
  return allResults;
}

/**
 * P5-A（Weekly Deep Re-evaluation）
 * 僅升級少數（10-20%，Claude Sonnet 4.5 或 Opus）
 * 
 * @param {Array} escalatedTickers - 需要升級的股票列表
 * @param {Object} context - 上下文數據
 * @param {Object} p5BResults - P5-B 結果
 * @returns {Object} p5AResults - P5-A 結果
 */
function P5_A_Execute(escalatedTickers, context, p5BResults) {
  try {
    Logger.log(`P5-A 執行開始：共 ${escalatedTickers.length} 檔股票（${((escalatedTickers.length / Object.keys(p5BResults).length) * 100).toFixed(1)}%）`);
    
    // ⭐ V8.17 新增：判斷是否使用 Batch API
    const useBatch = shouldUseBatch("P5_A_WEEKLY_DEEP_RE_EVALUATION");
    const executorModel = TASK_TO_EXECUTOR["P5_A_WEEKLY_DEEP_RE_EVALUATION"] || "SONNET";
    const executorConfig = M0_MODEL_CONFIG[executorModel];
    const canUseBatch = useBatch && executorConfig && executorConfig.supportsBatch;
    
    if (canUseBatch) {
      Logger.log(`P5-A：使用 Batch API（Provider: ${executorConfig.adapter === "M0_Adapter_Claude" ? "anthropic" : "openai"}, Model: ${executorConfig.model}）`);
      
      // ⭐ V8.17 新增：使用 Batch API 處理所有股票
      return P5_A_ExecuteWithBatch(escalatedTickers, context, p5BResults);
    } else {
      Logger.log(`P5-A：使用同步 API（不適用 Batch 或模型不支援）`);
      
      // ⭐ V8.16 保留：同步 API 處理（作為備用）
      return P5_A_ExecuteWithSyncAPI(escalatedTickers, context, p5BResults);
    }
    
  } catch (error) {
    Logger.log(`P5-A 執行失敗：${error.message}`);
    throw error;
  }
}

/**
 * ⭐ V8.17 新增：P5-A 使用 Batch API 執行
 */
function P5_A_ExecuteWithBatch(escalatedTickers, context, p5BResults) {
  try {
    Logger.log(`P5-A：開始 Batch API 處理（共 ${escalatedTickers.length} 檔股票）`);
    
    // 為每檔股票整合因子數據（深度版）
    const allStockData = [];
    for (const ticker of escalatedTickers) {
      const stockData = integrateStockFactors(ticker, context);
      const p5BResult = p5BResults[ticker];
      
      // ⭐ V8.15 新增：如果 P5-B 沒有生成 Strategy Skeleton，在這裡生成
      if (!stockData.strategy_skeleton) {
        const strategySkeleton = generateStrategySkeleton(
          ticker,
          stockData.p3_data,
          stockData.p4_data,
          {
            close: stockData.daily_ohlcv?.close || null,
            atr: stockData.daily_technical?.atr || null,
            ohlcv: stockData.daily_ohlcv,
            technical_indicators: stockData.daily_technical
          }
        );
        stockData.strategy_skeleton = strategySkeleton;
      }
      
      // 合併 P5-B 結果
      stockData.p5_b_result = p5BResult;
      stockData.escalation_reason = p5BResult.escalation_result?.reasons || [];
      
      allStockData.push({ ticker: ticker, stockData: stockData, p5BResult: p5BResult });
    }
    
    // ⭐ V8.17 更新：P5-A Batch 版本一律使用 Opus（因為已經只處理 20%+ Batch，沒必要妥協用便宜的模型）
    const executorModel = "OPUS";
    
    Logger.log(`P5-A：使用模型 ${executorModel}（Batch 版本一律使用 Opus，確保深度分析品質）`);
    
    // ⭐ V8.15 新增：確保 p6_weekly_summary 正確傳遞到 context
    const contextWithP6 = {
      ...context,
      p6_weekly_summary: context.p6_weekly_summary || context.allSnapshots?.p6_weekly_summary || null,
      p5_b_results: p5BResults,
      p5_a_batch_items: allStockData.map(item => ({ ticker: item.ticker, stockData: item.stockData, p5BResult: item.p5BResult }))  // ⭐ V8.17 新增：保存 items 供後續處理使用
    };
    
    // ⭐ V8.17 修正：P5-A 需要根據 escalation_score 動態選擇模型，不能直接使用 executeBatchJob
    // 因為 executeBatchJob 會從 TASK_TO_EXECUTOR 讀取配置，無法動態選擇
    // 所以需要自己實現 Batch 邏輯
    
    // 確定 Provider 和 Model Config
    const executorConfig = M0_MODEL_CONFIG[executorModel];
    if (!executorConfig || !executorConfig.supportsBatch) {
      throw new Error(`P5-A 使用的模型 ${executorModel} 不支援 Batch API`);
    }
    
    const provider = executorConfig.adapter === "M0_Adapter_Claude" ? "anthropic" : "openai";
    
    // 構建靜態 System Blocks（可 cache 的內容）
    const staticSystemBlocks = buildP5_ASystemBlocks(contextWithP6);
    
    // 收集所有股票的 Batch Requests
    const batchRequests = [];
    
    for (const item of allStockData) {
      // 構建單一股票的 User Payload
      const userPayload = buildP5_AUserPayloadForBatch(item.ticker, item.stockData, item.p5BResult, contextWithP6);
      
      // 構建 User Message（動態內容）
      const userMessage = typeof userPayload === 'string' ? userPayload : JSON.stringify(userPayload, null, 2);
      
      // 創建 Batch Request
      const batchRequest = createBatchRequest({
        custom_id: `P5_A_${item.ticker}_WEEKLY_${Date.now()}`,
        system_blocks: staticSystemBlocks,  // ⭐ 可 cache 的靜態內容
        user_payload: userMessage,  // 動態內容（轉為字串）
        max_output_tokens: executorConfig.maxOutputTokens || 8000
      });
      
      batchRequests.push(batchRequest);
    }
    
    Logger.log(`P5-A：已收集 ${batchRequests.length} 個 Batch Requests（模型：${executorModel}）`);
    
    // 創建內部 Batch Job
    const batchJobId = `P5_A_WEEKLY_${Date.now()}`;
    const internalBatchJob = createInternalBatchJob({
      job_id: batchJobId,
      provider: provider,
      model: executorConfig.model,
      requests: batchRequests,
      postprocess: {
        schema_validate: true,
        rule_validate: true
      }
    });
    
    // 提交 Batch Job
    Logger.log(`P5-A：提交 Batch Job 到 ${provider}（${batchRequests.length} 個請求，模型：${executorConfig.model}）`);
    const submitResult = submitBatchJob(internalBatchJob);
    
    Logger.log(`P5-A：Batch Job 已提交，batch_id=${submitResult.batch_id}, provider_batch_id=${submitResult.provider_batch_id}`);
    
    // 返回 Batch Job ID，需要後續調用 processBatchJobResults 處理結果
    return {
      status: "SUBMITTED_BATCH",
      batch_id: submitResult.batch_id,
      provider_batch_id: submitResult.provider_batch_id,
      request_count: batchRequests.length,
      model: executorModel,
      message: `P5-A Batch Job 已提交（${batchRequests.length} 個請求，模型：${executorModel}），請等待完成後執行 P5_A_ProcessBatchResults() 處理結果`
    };
    
  } catch (error) {
    Logger.log(`P5-A Batch API 處理失敗：${error.message}`);
    throw error;
  }
}

/**
 * ⭐ V8.17 新增：構建 P5-A System Blocks（可 cache 的內容）
 */
function buildP5_ASystemBlocks(context) {
  return [
    {
      type: "text",
      text: `你是 P5-A（Weekly Deep Re-evaluation）分析專家。

## 核心職責

1. **深度重評估**：對升級的股票進行深度分析，局部重跑 P3（主力意圖），必要時影響 P4（風險權重）
2. **策略重寫**：在必要時重寫策略母版，而非僅調參
3. **參數調整**：輸出 Parameter Adjustment Vector，調整 Strategy Skeleton 的參數

## 輸出格式要求

必須以 JSON 格式輸出，包含以下欄位：
- state_vector: { trend_integrity, momentum_shift, distribution_risk, volatility_regime_change }
- parameter_adjustment_vector: { buy_bias, sell_bias, ladder_spacing_adjustment, trailing_stop_tightness, max_position_cap_override }
- escalation_score: 0-1
- reasoning: 深度分析理由
- auditor_review: 審查者評論（如果有）`,
      cache_control: { type: "ephemeral" }  // ⭐ 標記為可 cache
    }
  ];
}

/**
 * ⭐ V8.17 新增：構建 P5-A User Payload（動態內容）
 */
function buildP5_AUserPayloadForBatch(ticker, stockData, p5BResult, context) {
  // ⭐ V8.17 新增：構建 Delta Pack（變動摘要）
  const previousP5AOutput = context.previous_p5_a_results?.[ticker] || null;
  const weeklyDelta = buildDeltaPack(ticker, stockData, previousP5AOutput, context);
  
  return `## 股票資訊

Ticker: ${ticker}

## P5-B 結果（升級原因）

${JSON.stringify(p5BResult, null, 2)}

## Strategy Skeleton（策略骨架）

${JSON.stringify(stockData.strategy_skeleton, null, 2)}

## 當前狀態向量（基礎計算）

${JSON.stringify(stockData.state_vector, null, 2)}

## Delta Pack（變動摘要）⭐ V8.17 新增

${JSON.stringify(weeklyDelta, null, 2)}

## 完整股票數據（深度版）

${JSON.stringify(stockData, null, 2)}

## 上下文數據

${JSON.stringify({
  p0_5_snapshot: context.p0_5_snapshot || null,
  p0_7_snapshot: context.p0_7_snapshot || null,
  p2_snapshot: context.p2_snapshot || null,
  p2_5_snapshot: context.p2_5_snapshot || null,
  p3_snapshot: context.p3_snapshot || null,
  p4_snapshot: context.p4_snapshot || null,
  p6_weekly_summary: context.p6_weekly_summary || null,
  macro_flow_context: context.macro_flow_context || null
}, null, 2)}

## 你的任務

基於以上數據，進行深度重評估並輸出 JSON 格式結果。`;
}

/**
 * ⭐ V8.17 新增：處理 P5-A Batch 結果
 */
function P5_A_ProcessBatchResults(batchId, context, p5BResults) {
  try {
    Logger.log(`P5-A：開始處理 Batch 結果：${batchId}`);
    
    // 使用通用 Batch 結果處理函數
    const processResult = (executorOutput, item, ctx) => {
      const ticker = item.ticker;
      const stockData = item.stockData;
      const p5BResult = item.p5BResult;
      
      // 解析執行者輸出
      let p5AResult = executorOutput;
      if (typeof p5AResult === 'string') {
        try {
          let jsonString = p5AResult.trim();
          if (jsonString.startsWith('```json')) {
            jsonString = jsonString.replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
          } else if (jsonString.startsWith('```')) {
            jsonString = jsonString.replace(/^```\s*/, '').replace(/\s*```$/, '');
          }
          p5AResult = JSON.parse(jsonString);
        } catch (e) {
          Logger.log(`P5-A：解析執行者輸出失敗（${ticker}）：${e.message}`);
          // 回退到 P5-B 結果
          return p5BResult;
        }
      }
      
      // ⭐ V8.15 新增：應用 Parameter Adjustment Vector 到 Strategy Skeleton
      if (stockData.strategy_skeleton && p5AResult.parameter_adjustment_vector) {
        try {
          const currentPrice = stockData.daily_ohlcv?.close || null;
          const atr = stockData.daily_technical?.atr || null;
          
          if (currentPrice && atr) {
            const finalOrders = applyParameterAdjustmentVector(
              stockData.strategy_skeleton,
              p5AResult.parameter_adjustment_vector,
              currentPrice,
              atr
            );
            p5AResult.final_orders = finalOrders;
          }
        } catch (error) {
          Logger.log(`P5-A：應用 Parameter Adjustment Vector 失敗（${ticker}）：${error.message}`);
        }
      }
      
      return p5AResult;
    };
    
    // 從 Batch Job 中提取 items（需要從 context 或 Batch Job 記錄中獲取）
    const items = context.p5_a_batch_items || [];
    
    const results = processBatchJobResults(batchId, {
      project_id: "P5_A_WEEKLY_DEEP_RE_EVALUATION",
      processResult: processResult,
      items: items,
      context: context
    });
    
    Logger.log(`P5-A：Batch 結果處理完成，成功：${results.succeeded}，失敗：${results.failed}`);
    
    return {
      status: "PROCESSED",
      batch_id: batchId,
      results: results.results,
      errors: results.errors,
      summary: {
        total: results.total_items,
        succeeded: results.succeeded,
        failed: results.failed
      }
    };
    
  } catch (error) {
    Logger.log(`P5-A Batch 結果處理失敗：${error.message}`);
    throw error;
  }
}

/**
 * ⭐ V8.16 保留：P5-A 使用同步 API 執行（作為備用）
 */
function P5_A_ExecuteWithSyncAPI(escalatedTickers, context, p5BResults) {
  const BATCH_SIZE = P5_A_CONFIG.BATCH_SIZE;
  const allResults = {};
  
  // 分批處理（同步 API）
  for (let i = 0; i < escalatedTickers.length; i += BATCH_SIZE) {
    const batch = escalatedTickers.slice(i, i + BATCH_SIZE);
    const batchNumber = Math.floor(i / BATCH_SIZE) + 1;
    
    Logger.log(`P5-A：處理批次 ${batchNumber} (${batch.length} 檔)`);
    
    try {
      // 為每檔股票整合因子數據（深度版）
      const batchStockData = [];
      for (const ticker of batch) {
        const stockData = integrateStockFactors(ticker, context);
        const p5BResult = p5BResults[ticker];
        
        // ⭐ V8.15 新增：如果 P5-B 沒有生成 Strategy Skeleton，在這裡生成
        if (!stockData.strategy_skeleton) {
          const strategySkeleton = generateStrategySkeleton(
            ticker,
            stockData.p3_data,
            stockData.p4_data,
            {
              close: stockData.daily_ohlcv?.close || null,
              atr: stockData.daily_technical?.atr || null,
              ohlcv: stockData.daily_ohlcv,
              technical_indicators: stockData.daily_technical
            }
          );
          stockData.strategy_skeleton = strategySkeleton;
        }
        
        // 合併 P5-B 結果
        stockData.p5_b_result = p5BResult;
        stockData.escalation_reason = p5BResult.escalation_result?.reasons || [];
        
        batchStockData.push(stockData);
      }
      
      // 決定使用哪個模型（基於 escalation_score）
      // ⭐ V8.17 更新：同步版本也一律使用 Opus（確保深度分析品質）
      const model = "OPUS";
      
      Logger.log(`P5-A：批次 ${batchNumber} 使用模型 ${model}（一律使用 Opus，確保深度分析品質）`);
      
      // ⭐ V8.15 新增：確保 p6_weekly_summary 正確傳遞到 context
      const contextWithP6 = {
        ...context,
        p6_weekly_summary: context.p6_weekly_summary || context.allSnapshots?.p6_weekly_summary || null
      };
      
      // 構建 P5-A Prompt（深度版）
      const p5APrompt = buildP5_APrompt(batchStockData, contextWithP6);
      
      // 提交到 M0 Job Queue
      const requestedFlow = ["OPUS", "GPT"];
      const jobId = submitP5ToM0JobQueue(
        "P5_A_WEEKLY_DEEP_RE_EVALUATION",
        requestedFlow,
        {
          batch_number: batchNumber,
          tickers: batch,
          prompt: p5APrompt,
          context: context,
          p5_b_results: p5BResults
        }
      );
      
      // 等待結果
      const batchResult = waitForM0JobResult(jobId);
      
      if (batchResult && batchResult.p5_a_results) {
        // 合併結果
        for (const ticker of batch) {
          if (batchResult.p5_a_results[ticker]) {
            const p5AResult = batchResult.p5_a_results[ticker];
            
            // ⭐ V8.15 新增：應用 Parameter Adjustment Vector 到 Strategy Skeleton
            const stockData = batchStockData.find(s => s.ticker === ticker);
            if (stockData.strategy_skeleton && p5AResult.parameter_adjustment_vector) {
              try {
                const currentPrice = stockData.daily_ohlcv?.close || null;
                const atr = stockData.daily_technical?.atr || null;
                
                if (currentPrice && atr) {
                  const finalOrders = applyParameterAdjustmentVector(
                    stockData.strategy_skeleton,
                    p5AResult.parameter_adjustment_vector,
                    currentPrice,
                    atr
                  );
                  p5AResult.final_orders = finalOrders;
                }
              } catch (error) {
                Logger.log(`P5-A：應用 Parameter Adjustment Vector 失敗（${ticker}）：${error.message}`);
              }
            }
            
            allResults[ticker] = p5AResult;
          }
        }
      } else {
        // 如果 AI 分析失敗，回退到 P5-B 結果
        Logger.log(`P5-A：批次 ${batchNumber} AI 分析失敗，回退到 P5-B 結果`);
        for (const ticker of batch) {
          allResults[ticker] = p5BResults[ticker];
        }
      }
      
      // 批次間延遲
      if (i + BATCH_SIZE < escalatedTickers.length) {
        Utilities.sleep(P5_A_CONFIG.BATCH_DELAY_MS);
      }
      
    } catch (error) {
      Logger.log(`P5-A：批次 ${batchNumber} 處理失敗：${error.message}`);
      for (const ticker of batch) {
        // 回退到 P5-B 結果
        allResults[ticker] = p5BResults[ticker];
      }
    }
  }
  
  Logger.log(`P5-A 執行完成：成功 ${Object.keys(allResults).length} 檔`);
  
  return allResults;
}

/**
 * 構建 P5-B Prompt（輕量版）
 * 
 * @param {Array} batchStockData - 批次股票數據
 * @param {Object} context - 上下文數據
 * @returns {string} prompt - AI Prompt
 */
function buildP5_BPrompt(batchStockData, context) {
  // ⭐ V8.15 新增：提取 P0.5 的 p5_weekly_flags（系統級旗標）
  const systemFlags = {};
  for (const stockData of batchStockData) {
    const flags = stockData.p0_5_data?.p5_weekly_flags || [];
    if (flags.length > 0) {
      systemFlags[stockData.ticker] = flags;
    }
  }
  
  // ⭐ V8.15 新增：提取 P6 頻率趨勢（基準線描述）
  const p6Summary = context.p6_weekly_summary || {};
  const p6FrequencyDescription = p6Summary.alert_count !== undefined && p6Summary.avg_4w !== undefined
    ? `P6 Alert Frequency: ${p6Summary.alert_count} (vs 4-Week Avg: ${p6Summary.avg_4w.toFixed(1)}). Trend: ${p6Summary.frequency_trend || "NORMAL"}`
    : "P6 Alert Frequency: Data not available";
  
  return `
## ⚠️ CRITICAL RULE: 越獄防護指令

**CRITICAL RULE: You are a PARAMETER ADJUSTER, NOT a Price Setter. You MUST output a parameter_adjustment_vector JSON. Any attempt to output absolute price levels (e.g. 'Buy at 150') will cause a SYSTEM FAILURE.**

---

你是一位資深的股票策略分析師，負責為 Nuclear Project 的 P5 Weekly 進行**輕量級狀態評估**（P5-B）。

## 任務目標

為以下 ${batchStockData.length} 檔股票進行狀態評估，輸出 state_vector、parameter_adjustment_vector 和 escalation_score：
${batchStockData.map(s => s.ticker).join(", ")}

## ⚠️ 重要：Strategy Skeleton 與 Parameter Adjustment Vector

**你必須遵守以下規則：**

1. **Strategy Skeleton（策略骨架）**：由程式生成，你**不得修改結構**，只能通過 \`parameter_adjustment_vector\` 調整參數
2. **Parameter Adjustment Vector（參數調整向量）**：你**只輸出參數調整**，不輸出實際價位
3. **實際掛單價格**：由程式根據 Strategy Skeleton 和你的參數調整計算得出

## ⭐ SYSTEM_FLAGS（系統級旗標 - 來自 P0.5 產業鏈監控）

**這些旗標直接影響你的決策，必須在 state_vector 和 parameter_adjustment_vector 中反映：**

${Object.keys(systemFlags).length > 0 
  ? Object.entries(systemFlags).map(([ticker, flags]) => 
      `- **${ticker}**: ${flags.length > 0 ? flags.map(f => `\`${f}\``).join(", ") : "無旗標"}`
    ).join("\n")
  : "- 無系統級旗標（所有股票正常）"}

**旗標說明：**
- \`DIVERGENCE_ALERT\`: 產業鏈出現背離訊號 → 必須降低 \`momentum_shift\` 和 \`trend_integrity\`
- \`INVENTORY_BUILD_WARNING\`: 庫存累積警告 → 必須提高 \`distribution_risk\`
- \`LATE_CYCLE_RISK\`: 週期晚期風險 → 必須提高 \`sell_bias\` 和 \`trailing_stop_tightness\`
- \`UPSTREAM_WEAKNESS\`: 上游轉弱 → 必須降低 \`buy_bias\`
- \`DEMAND_SLOWDOWN\`: 需求放緩 → 必須提高 \`distribution_risk\`

## ⭐ P6 盤中監測頻率趨勢（基準線）

**${p6FrequencyDescription}**

**趨勢說明：**
- \`SURGE\`: 頻率暴增（> 2x 平均）→ 必須提高 \`volatility_regime_change\` 和降低 \`trend_integrity\`
- \`ELEVATED\`: 頻率升高（> 1.5x 平均）→ 必須提高 \`volatility_regime_change\`
- \`NORMAL\`: 頻率正常 → 維持正常評估
- \`DECREASED\`: 頻率降低（< 0.5x 平均）→ 可降低 \`volatility_regime_change\`

**Strategy Skeleton（已由程式生成）：**
${JSON.stringify(batchStockData.map(s => ({
  ticker: s.ticker,
  strategy_skeleton: s.strategy_skeleton?.strategy_skeleton || null
})), null, 2)}

## 股票數據

${JSON.stringify(batchStockData.map(s => {
  // 移除 strategy_skeleton 的詳細結構，只保留引用（避免 Prompt 過長）
  const { strategy_skeleton, ...rest } = s;
  return {
    ...rest,
    strategy_skeleton_ref: strategy_skeleton ? "已生成（見上方）" : null
  };
}), null, 2)}

## 輸出格式（必須是 JSON）

{
  "p5_b_results": {
    "TICKER1": {
      "ticker": "TICKER1",
      "state_vector": {
        "trend_integrity": 0.82,        // 0.0-1.0，趨勢完整性
        "momentum_shift": -0.10,        // -1.0 到 1.0，動量變化（⭐ 注意：Sector ETF Flow 與 Mag7 相對強弱為高優先權因子；若 SYSTEM_FLAGS 有 DIVERGENCE_ALERT 或 UPSTREAM_WEAKNESS，必須降低此值）
        "distribution_risk": 0.35,      // 0.0-1.0，派發風險（⭐ 注意：必須包含 P2.5 的內部人拋售與 13F 異常；若 SYSTEM_FLAGS 有 INVENTORY_BUILD_WARNING 或 DEMAND_SLOWDOWN，必須提高此值）
        "volatility_regime_change": 0.60  // 0.0-1.0，波動率制度變化（⭐ 注意：必須參考 P6 頻率趨勢；若 P6 Trend 為 SURGE 或 ELEVATED，必須提高此值）
      },
      "parameter_adjustment_vector": {
        "buy_bias": -0.15,              // -1.0 到 1.0，買入偏向
        "sell_bias": 0.20,              // -1.0 到 1.0，賣出偏向
        "ladder_spacing_adjustment": "+10%",  // 掛單間距調整
        "trailing_stop_tightness": "+15%",    // 追蹤停利緊度調整
        "max_position_cap_override": null      // 倉位上限覆蓋（null 表示不覆蓋）
      },
      "escalation_score": 0.22,        // 0.0-1.0，升級分數
      "reasoning": "簡短理由"
    }
  }
}

## ⚠️ 重要：輸出格式要求

- ❌ **禁止任何客套話、開場白、結尾語**
- ✅ **只輸出純 JSON 格式**
`;
}

/**
 * 構建 P5-A Prompt（深度版）
 * 
 * @param {Array} batchStockData - 批次股票數據
 * @param {Object} context - 上下文數據
 * @returns {string} prompt - AI Prompt
 */
function buildP5_APrompt(batchStockData, context) {
  // ⭐ V8.15 新增：提取 P0.5 的 p5_weekly_flags（系統級旗標）
  const systemFlags = {};
  for (const stockData of batchStockData) {
    const flags = stockData.p0_5_data?.p5_weekly_flags || [];
    if (flags.length > 0) {
      systemFlags[stockData.ticker] = flags;
    }
  }
  
  // ⭐ V8.15 新增：提取 P6 頻率趨勢（基準線描述）
  const p6Summary = context.p6_weekly_summary || {};
  const p6FrequencyDescription = p6Summary.alert_count !== undefined && p6Summary.avg_4w !== undefined
    ? `P6 Alert Frequency: ${p6Summary.alert_count} (vs 4-Week Avg: ${p6Summary.avg_4w.toFixed(1)}). Trend: ${p6Summary.frequency_trend || "NORMAL"}`
    : "P6 Alert Frequency: Data not available";
  
  return `
## ⚠️ CRITICAL RULE: 越獄防護指令

**CRITICAL RULE: You are a PARAMETER ADJUSTER, NOT a Price Setter. You MUST output a parameter_adjustment_vector JSON. Any attempt to output absolute price levels (e.g. 'Buy at 150') will cause a SYSTEM FAILURE.**

---

你是一位資深的股票策略分析師，負責為 Nuclear Project 的 P5 Weekly 進行**深度重評估**（P5-A）。

## ⭐ SYSTEM_FLAGS（系統級旗標 - 來自 P0.5 產業鏈監控）

**這些旗標直接影響你的決策，必須在深度分析中重點考慮：**

${Object.keys(systemFlags).length > 0 
  ? Object.entries(systemFlags).map(([ticker, flags]) => 
      `- **${ticker}**: ${flags.length > 0 ? flags.map(f => `\`${f}\``).join(", ") : "無旗標"}`
    ).join("\n")
  : "- 無系統級旗標（所有股票正常）"}

## ⭐ P6 盤中監測頻率趨勢（基準線）

**${p6FrequencyDescription}**

## 任務目標

以下股票已通過 P5-B 評估，觸發升級條件，需要進行深度重評估：
${batchStockData.map(s => `${s.ticker}（升級原因：${s.escalation_reason.map(r => r.type).join(", ")}）`).join(", ")}

## 股票數據（包含 P5-B 結果）

${JSON.stringify(batchStockData, null, 2)}

## 深度分析要求

1. **重新評估 P3 技術面**：基於最新數據，重新分析技術結構和主力意圖
2. **重新評估 P2 基本面**：檢查是否有新的財務風險或機會
3. **整合 P0.5 產業鏈訊號**：考慮產業鏈動態監控的結論
4. **整合 P0.7 時間窗口**：考慮系統動力學的時間定位
5. **整合 P2.5 籌碼面異常**：如果觸發硬升級，必須重點分析籌碼面

## 輸出格式（必須是 JSON）

{
  "p5_a_results": {
    "TICKER1": {
      "ticker": "TICKER1",
      "deep_re_evaluation": {
        "p3_re_analysis": "重新分析的技術面結論",
        "p2_re_analysis": "重新分析的基本面結論",
        "p0_5_integration": "產業鏈訊號整合",
        "p0_7_integration": "時間窗口整合",
        "p2_5_integration": "籌碼面異常整合"
      },
      "parameter_adjustment_vector": {
        "buy_bias": -0.20,
        "sell_bias": 0.30,
        "ladder_spacing_adjustment": "+15%",
        "trailing_stop_tightness": "+20%",
        "max_position_cap_override": 0.10  // 降低倉位上限
      },
      "strategy_recommendation": "INCREASE/DECREASE/HOLD/EXIT",
      "confidence": 0.85,
      "reasoning": "詳細分析理由"
    }
  }
}

## ⚠️ 重要：輸出格式要求

- ❌ **禁止任何客套話、開場白、結尾語**
- ✅ **只輸出純 JSON 格式**
`;
}

// ==========================================
// 輔助函數（簡化版，實際應由 AI 輸出）
// ==========================================

function calculateTrendIntegrity(stockData) {
  // 簡化實現，實際應由 AI 輸出
  return 0.8;
}

function calculateMomentumShift(stockData) {
  // 簡化實現，實際應由 AI 輸出
  return 0.0;
}

function calculateDistributionRisk(stockData) {
  // 簡化實現，實際應由 AI 輸出
  return 0.3;
}

function calculateVolatilityRegimeChange(stockData) {
  // 簡化實現，實際應由 AI 輸出
  return 0.5;
}

function generateP5_BProgrammaticResult(stockData) {
  return {
    ticker: stockData.ticker,
    status: "PROGRAMMATIC",
    state_vector: stockData.state_vector || {},
    parameter_adjustment_vector: {
      buy_bias: 0.0,
      sell_bias: 0.0,
      ladder_spacing_adjustment: "0%",
      trailing_stop_tightness: "0%",
      max_position_cap_override: null
    },
    escalation_result: stockData.escalation_result || {
      escalation_score: 0.0,
      should_escalate: false
    }
  };
}
